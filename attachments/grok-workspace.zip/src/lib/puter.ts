import type { PuterUser } from "./types";

const PUTER_SRC = "https://js.puter.com/v2/";

export type PuterChatMessage = {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  tool_call_id?: string;
};

type ToolCall = {
  id?: string;
  type?: string;
  function?: { name?: string; arguments?: string };
  name?: string;
  input?: unknown;
};

export type PuterAI = {
  chat: (
    prompt: string | PuterChatMessage[],
    testModeOrOptions?: boolean | Record<string, unknown>,
    options?: Record<string, unknown>,
  ) => Promise<unknown>;
  listModels?: () => Promise<unknown>;
};

export type PuterSDK = {
  auth: {
    signIn: (opts?: {
      attempt_temp_user_creation?: boolean;
      request_auth?: boolean;
    }) => Promise<unknown>;
    signOut: () => void | Promise<void>;
    isSignedIn: () => boolean;
    getUser: () => Promise<PuterUser>;
  };
  ai: PuterAI;
  kv: {
    set: (key: string, value: unknown) => Promise<unknown>;
    get: (key: string) => Promise<unknown>;
    del?: (key: string) => Promise<unknown>;
  };
  fs: {
    write: (path: string, content: string | Blob) => Promise<unknown>;
    read: (path: string) => Promise<Blob | string>;
    mkdir: (path: string) => Promise<unknown>;
    readdir?: (path: string) => Promise<unknown>;
  };
  hosting: {
    create: (subdomain: string, dir: string) => Promise<{ subdomain: string }>;
    update?: (subdomain: string, dir: string) => Promise<unknown>;
    list?: () => Promise<unknown>;
  };
  randName?: () => string;
};

declare global {
  interface Window {
    puter?: PuterSDK;
  }
}

let loading: Promise<PuterSDK> | null = null;

function loadPuterScript(): Promise<PuterSDK> {
  return new Promise((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>(
      `script[src="${PUTER_SRC}"]`,
    );
    const done = () => {
      if (window.puter) resolve(window.puter);
      else reject(new Error("Puter.js loaded without window.puter"));
    };
    if (existing) {
      if (window.puter) {
        resolve(window.puter);
        return;
      }
      existing.addEventListener("load", done, { once: true });
      existing.addEventListener(
        "error",
        () => reject(new Error("Failed to load Puter.js")),
        { once: true },
      );
      return;
    }
    const script = document.createElement("script");
    script.src = PUTER_SRC;
    script.async = true;
    script.onload = done;
    script.onerror = () => reject(new Error("Failed to load Puter.js"));
    document.head.appendChild(script);
  });
}

export async function getPuter(): Promise<PuterSDK> {
  if (typeof window === "undefined") {
    throw new Error("Puter only runs in the browser");
  }
  if (window.puter) return window.puter;
  if (!loading) {
    loading = loadPuterScript().catch((err: unknown) => {
      loading = null;
      throw err;
    });
  }
  return loading;
}

export async function puterSignIn(): Promise<PuterUser> {
  const puter = await getPuter();
  await puter.auth.signIn({ attempt_temp_user_creation: true });
  return puter.auth.getUser();
}

export async function puterSignOut(): Promise<void> {
  const puter = await getPuter();
  await puter.auth.signOut();
}

export function isPuterSignedIn(): boolean {
  try {
    return Boolean(window.puter?.auth.isSignedIn());
  } catch {
    return false;
  }
}

export async function currentPuterUser(): Promise<PuterUser | null> {
  const puter = await getPuter();
  if (!puter.auth.isSignedIn()) return null;
  try {
    return await puter.auth.getUser();
  } catch {
    return null;
  }
}

export function chunkText(part: unknown): string {
  if (!part) return "";
  if (typeof part === "string") return part;
  if (typeof part !== "object") return "";
  const p = part as Record<string, unknown>;
  if (typeof p.text === "string") return p.text;
  if (typeof p.content === "string") return p.content;
  if (p.delta && typeof p.delta === "object") {
    const d = p.delta as Record<string, unknown>;
    if (typeof d.content === "string") return d.content;
    if (typeof d.text === "string") return d.text;
  }
  const msg = p.message as Record<string, unknown> | undefined;
  if (msg && typeof msg.content === "string") return msg.content;
  return "";
}

export function extractToolCalls(part: unknown): {
  id: string;
  name: string;
  args: Record<string, unknown>;
}[] {
  if (!part || typeof part !== "object") return [];
  const p = part as Record<string, unknown>;
  const out: { id: string; name: string; args: Record<string, unknown> }[] = [];

  if (p.type === "tool_use" && typeof p.name === "string") {
    out.push({
      id: String(p.id ?? p.tool_use_id ?? `tool_${out.length}`),
      name: p.name,
      args: asArgs(p.input ?? p.arguments),
    });
  }

  const calls = (p.tool_calls ||
    (p.message as Record<string, unknown> | undefined)?.tool_calls) as
    | ToolCall[]
    | undefined;
  if (Array.isArray(calls)) {
    for (const c of calls) {
      const name = c.function?.name || c.name;
      if (!name) continue;
      out.push({
        id: String(c.id ?? `tool_${out.length}`),
        name,
        args: asArgs(c.function?.arguments ?? c.input),
      });
    }
  }
  return out;
}

function asArgs(raw: unknown): Record<string, unknown> {
  if (!raw) return {};
  if (typeof raw === "string") {
    try {
      const parsed = JSON.parse(raw) as unknown;
      if (parsed && typeof parsed === "object") {
        return parsed as Record<string, unknown>;
      }
    } catch {
      return { value: raw };
    }
  }
  if (typeof raw === "object") return raw as Record<string, unknown>;
  return {};
}

export async function consumeChat(
  result: unknown,
  onChunk: (text: string, raw: unknown) => void,
): Promise<string> {
  let full = "";
  if (result && typeof result === "object" && Symbol.asyncIterator in result) {
    for await (const part of result as AsyncIterable<unknown>) {
      const t = chunkText(part);
      if (t) full += t;
      onChunk(t, part);
    }
    return full;
  }
  const t = chunkText(result);
  if (t) {
    full = t;
    onChunk(t, result);
  }
  return full;
}

export function slugify(input: string): string {
  const base = input
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 24);
  const n = Math.random().toString(36).slice(2, 6);
  return `${base || "pulse"}-${n}`;
}
