export type ModelOption = {
  id: string;
  label: string;
  hint: string;
  provider: string;
};

export const MODEL_OPTIONS: ModelOption[] = [
  {
    id: "auto",
    label: "Auto",
    hint: "Routes the right model for the job",
    provider: "pulse",
  },
  {
    id: "gpt-5-nano",
    label: "GPT-5 Nano",
    hint: "Fast default for most builds",
    provider: "openai",
  },
  {
    id: "gpt-5.4-nano",
    label: "GPT-5.4 Nano",
    hint: "Stronger reasoning, still quick",
    provider: "openai",
  },
  {
    id: "gpt-5.6-luna",
    label: "GPT-5.6 Luna",
    hint: "Highest quality OpenAI route",
    provider: "openai",
  },
  {
    id: "claude-sonnet-4",
    label: "Claude Sonnet 4",
    hint: "Great at UI and long files",
    provider: "anthropic",
  },
  {
    id: "claude-opus-4",
    label: "Claude Opus 4",
    hint: "Deepest agent work",
    provider: "anthropic",
  },
  {
    id: "google/gemini-2.5-flash",
    label: "Gemini 2.5 Flash",
    hint: "Fast multimodal Google model",
    provider: "google",
  },
  {
    id: "deepseek-chat",
    label: "DeepSeek Chat",
    hint: "Sharp code, low cost",
    provider: "deepseek",
  },
];

export function routeModel(opts: {
  selected: string;
  mode: "agent" | "chat";
  prompt: string;
}): string {
  if (opts.selected && opts.selected !== "auto") return opts.selected;
  const len = opts.prompt.trim().length;
  if (opts.mode === "chat" && len < 280) return "gpt-5-nano";
  if (len > 900 || /auth|payment|dashboard|multiplayer|3d|native/i.test(opts.prompt)) {
    return "gpt-5.6-luna";
  }
  if (opts.mode === "agent") return "claude-sonnet-4";
  return "gpt-5-nano";
}

export function modelLabel(id: string): string {
  return MODEL_OPTIONS.find((m) => m.id === id)?.label ?? id;
}
