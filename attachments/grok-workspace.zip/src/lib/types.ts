export type BuildType =
  | "web"
  | "mobile"
  | "slides"
  | "dashboard"
  | "video"
  | "other";

export type InteractionMode = "agent" | "chat";

export type ProjectStatus = "draft" | "building" | "ready" | "error";

export type TaskStatus = "queued" | "running" | "done" | "error";

export type FileMap = Record<string, string>;

export type AgentBlock =
  | { kind: "text"; text: string }
  | { kind: "thinking"; text: string }
  | { kind: "file"; path: string; action: "write" | "read" | "delete" }
  | { kind: "task"; title: string; status: TaskStatus };

export type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: number;
  blocks?: AgentBlock[];
  filesChanged?: string[];
};

export type ProjectTask = {
  id: string;
  title: string;
  detail?: string;
  status: TaskStatus;
};

export type Project = {
  id: string;
  name: string;
  prompt: string;
  buildType: BuildType;
  mode: InteractionMode;
  status: ProjectStatus;
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
  files: FileMap;
  messages: ChatMessage[];
  tasks: ProjectTask[];
  publishedUrl?: string;
  publishedSubdomain?: string;
  model: string;
};

export type PuterUser = {
  username?: string;
  uuid?: string;
  email?: string;
};
