import type { FileMap } from "./types";

const FENCE =
  /(?:^|\n)(?:===FILE:\s*([^\n=]+?)===|```(?:[\w.+-]+)?(?:\s+([\w./-]+))?\s*\n)([\s\S]*?)(?:\n===END===|\n```)/g;

export function parseFilesFromText(text: string): FileMap {
  const files: FileMap = {};
  const re = new RegExp(FENCE.source, "g");
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    const named = (m[1] || m[2] || "").trim().replace(/^\/+/, "");
    const body = m[3]?.replace(/\n$/, "") ?? "";
    if (!named || !body.trim()) continue;
    files[named] = body;
  }

  if (Object.keys(files).length === 0) {
    const html = text.match(/<!DOCTYPE html>[\s\S]*<\/html>/i)?.[0];
    if (html) files["index.html"] = html;
  }
  return files;
}

export function mergeFiles(base: FileMap, next: FileMap): FileMap {
  return { ...base, ...next };
}

export function previewHtml(files: FileMap): string {
  const index =
    files["index.html"] ||
    files["index.htm"] ||
    Object.entries(files).find(([k]) => k.endsWith(".html"))?.[1];

  if (index) {
    let html = index;
    const css = collect(files, (k) => k.endsWith(".css") && k !== "index.html");
    const js = collect(files, (k) => k.endsWith(".js") && !k.endsWith(".json"));
    if (css && !/<link[^>]+stylesheet/i.test(html) && !/<style/i.test(html)) {
      html = html.replace("</head>", `<style>${css}</style></head>`);
      if (!html.includes("</head>")) html = `<style>${css}</style>` + html;
    }
    if (js && !/<script/i.test(html)) {
      html = html.replace("</body>", `<script>${js}</script></body>`);
      if (!html.includes("</body>")) html += `<script>${js}</script>`;
    }
    return html;
  }

  const md = files["README.md"] || files["readme.md"];
  if (md) {
    return wrapDoc(
      `<pre style="white-space:pre-wrap;font:14px/1.5 ui-monospace,monospace">${escapeHtml(md)}</pre>`,
    );
  }

  const first = Object.entries(files)[0];
  if (!first) {
    return wrapDoc(
      `<div style="height:100%;display:grid;place-items:center;color:#71717a;font-family:system-ui">Nothing to preview yet</div>`,
    );
  }
  return wrapDoc(
    `<pre style="white-space:pre-wrap;font:13px/1.5 ui-monospace,monospace;padding:24px">${escapeHtml(first[1])}</pre>`,
  );
}

function collect(files: FileMap, pred: (k: string) => boolean): string {
  return Object.entries(files)
    .filter(([k]) => pred(k))
    .map(([, v]) => v)
    .join("\n\n");
}

function wrapDoc(body: string): string {
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;height:100%;background:#0c0c0d;color:#f4f4f5}</style></head><body>${body}</body></html>`;
}

export function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "\u0026amp;")
    .replace(/</g, "\u0026lt;")
    .replace(/>/g, "\u0026gt;")
    .replace(/"/g, "\u0026quot;");
}

export function fileList(files: FileMap): string[] {
  return Object.keys(files).sort((a, b) => {
    if (a === "index.html") return -1;
    if (b === "index.html") return 1;
    return a.localeCompare(b);
  });
}
