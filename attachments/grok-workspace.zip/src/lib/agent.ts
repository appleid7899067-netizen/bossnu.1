import type { AgentBlock, ChatMessage, FileMap, InteractionMode, Project } from "./types";
import {
  consumeChat,
  extractToolCalls,
  getPuter,
  type PuterChatMessage,
} from "./puter";
import { mergeFiles, parseFilesFromText } from "./files";
import { routeModel } from "./models";
import { uid } from "./utils";
import { usePulse } from "./store";

const AGENT_TOOLS = [
  {
    type: "function",
    function: {
      name: "write_file",
      description: "Create or overwrite a project file. Use relative paths like index.html, styles.css, app.js.",
      parameters: {
        type: "object",
        properties: {
          path: { type: "string" },
          content: { type: "string" },
        },
        required: ["path", "content"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "read_file",
      description: "Read a file from the current project.",
      parameters: {
        type: "object",
        properties: { path: { type: "string" } },
        required: ["path"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "list_files",
      description: "List all files in the current project.",
      parameters: { type: "object", properties: {} },
    },
  },
  {
    type: "function",
    function: {
      name: "delete_file",
      description: "Delete a file from the current project.",
      parameters: {
        type: "object",
        properties: { path: { type: "string" } },
        required: ["path"],
      },
    },
  },
];

function systemPrompt(project: Project, mode: InteractionMode): string {
  const fileIndex = Object.keys(project.files);
  return `You are Pulse Agent, an expert product engineer and designer. You vibe-code complete, beautiful, working apps.

Product: Pulse — an AI app builder. Auth and models run on Puter. Never mention competing products.

Mode: ${mode === "chat" ? "CHAT — brainstorm, answer, plan. Do not write files unless the user explicitly asks you to build." : "AGENT — you MUST build a complete working app by writing files. Do not stop at a plan."}

Build type: ${project.buildType}

Current files: ${fileIndex.length ? fileIndex.join(", ") : "(none yet)"}

Rules:
- Ship a real, self-contained web app that runs in an iframe with no external JS CDNs (Google Fonts CSS is ok).
- Prefer index.html as the entry. You may add styles.css and app.js. Inline CSS/JS is fine.
- Mobile-first, tap targets ≥44px, no horizontal overflow.
- Distinctive visual design: not generic SaaS purple, not Inter-on-white. Commit to a point of view.
- Include realistic sample content, working interactions, and empty/loading states.
- ${project.buildType === "mobile" ? "Design as a phone app (fixed app chrome, bottom nav if needed)." : ""}
- ${project.buildType === "slides" ? "Full-viewport slides, keyboard arrows + dots, one idea per slide." : ""}
- ${project.buildType === "dashboard" ? "Dense dashboard with KPIs and at least one chart drawn with SVG or canvas (no chart CDN)." : ""}
- When building, use write_file tools. If tools are unavailable, emit files as:
===FILE: index.html===
...contents...
===END===
- After building, give a short, concrete summary of what you made and how to try it. No fluff.
- Reply in the same language the user writes in.
- Keep assistant prose concise. The product is the files.`;
}

function applyTool(
  files: FileMap,
  name: string,
  args: Record<string, unknown>,
): { files: FileMap; result: string; block?: AgentBlock } {
  if (name === "write_file") {
    const path = String(args.path ?? "index.html").replace(/^\/+/, "");
    const content = String(args.content ?? "");
    return {
      files: { ...files, [path]: content },
      result: `Wrote ${path} (${content.length} chars)`,
      block: { kind: "file", path, action: "write" },
    };
  }
  if (name === "read_file") {
    const path = String(args.path ?? "");
    const content = files[path];
    return {
      files,
      result: content == null ? `Not found: ${path}` : content,
      block: { kind: "file", path, action: "read" },
    };
  }
  if (name === "list_files") {
    const keys = Object.keys(files);
    return {
      files,
      result: keys.length ? keys.join("\n") : "(empty project)",
    };
  }
  if (name === "delete_file") {
    const path = String(args.path ?? "");
    const next = { ...files };
    delete next[path];
    return {
      files: next,
      result: `Deleted ${path}`,
      block: { kind: "file", path, action: "delete" },
    };
  }
  return { files, result: `Unknown tool ${name}` };
}

export async function runAgent(opts: {
  projectId: string;
  userText: string;
  abort?: AbortSignal;
}): Promise<void> {
  const store = usePulse.getState();
  const project = store.project(opts.projectId);
  if (!project) throw new Error("Project not found");

  const userMsg: ChatMessage = {
    id: uid("msg"),
    role: "user",
    content: opts.userText,
    createdAt: Date.now(),
  };
  store.appendMessage(opts.projectId, userMsg);

  const assistantId = uid("msg");
  const assistant: ChatMessage = {
    id: assistantId,
    role: "assistant",
    content: "",
    createdAt: Date.now(),
    blocks: [{ kind: "thinking", text: "Starting…" }],
  };
  store.appendMessage(opts.projectId, assistant);
  store.updateProject(opts.projectId, { status: "building" });

  const mode = project.mode;
  const model = routeModel({
    selected: store.settings.model === "auto" ? "auto" : store.settings.model,
    mode,
    prompt: opts.userText,
  });

  let files: FileMap = { ...project.files };
  const blocks: AgentBlock[] = [];
  let prose = "";
  const changed = new Set<string>();

  const history: PuterChatMessage[] = [
    { role: "system", content: systemPrompt({ ...project, files }, mode) },
    ...project.messages.slice(-12).map((m) => ({
      role: m.role,
      content: m.content,
    })),
    { role: "user", content: opts.userText },
  ];

  try {
    const puter = await getPuter();
    const maxTurns = mode === "chat" ? 2 : 8;

    for (let turn = 0; turn < maxTurns; turn++) {
      if (opts.abort?.aborted) throw new Error("Cancelled");

      const options: Record<string, unknown> = {
        model,
        stream: true,
      };
      if (mode === "agent") options.tools = AGENT_TOOLS;

      const call = store.settings.freeMode
        ? puter.ai.chat(history, true, options)
        : puter.ai.chat(history, options);

      const pendingTools: {
        id: string;
        name: string;
        args: Record<string, unknown>;
      }[] = [];
      let turnText = "";

      await consumeChat(await call, (text, raw) => {
        if (text) {
          turnText += text;
          prose += text;
          usePulse.getState().patchMessage(opts.projectId, assistantId, {
            content: prose,
            blocks: [...blocks],
          });
        }
        const tools = extractToolCalls(raw);
        for (const t of tools) pendingTools.push(t);
      });

      const parsed = parseFilesFromText(turnText);
      if (Object.keys(parsed).length) {
        files = mergeFiles(files, parsed);
        for (const path of Object.keys(parsed)) {
          changed.add(path);
          blocks.push({ kind: "file", path, action: "write" });
        }
        usePulse.getState().setFiles(opts.projectId, files);
      }

      if (!pendingTools.length) break;

      for (const tool of pendingTools) {
        const applied = applyTool(files, tool.name, tool.args);
        files = applied.files;
        if (applied.block) {
          blocks.push(applied.block);
          if (applied.block.kind === "file" && applied.block.action === "write") {
            changed.add(applied.block.path);
          }
        }
        history.push({
          role: "assistant",
          content: turnText || `call ${tool.name}`,
        });
        history.push({
          role: "tool",
          tool_call_id: tool.id,
          content: applied.result,
        });
      }
      usePulse.getState().setFiles(opts.projectId, files);
      usePulse.getState().patchMessage(opts.projectId, assistantId, {
        content: prose,
        blocks: [...blocks],
        filesChanged: [...changed],
      });
    }

    if (mode === "agent" && Object.keys(files).length === 0) {
      blocks.push({
        kind: "text",
        text: "Agent did not emit files. Try again, or switch model in Account.",
      });
    }

    const hasFiles = Object.keys(files).length > 0;
    usePulse.getState().setFiles(opts.projectId, files);
    usePulse.getState().patchMessage(opts.projectId, assistantId, {
      content: prose.trim() || (hasFiles ? "Built the first version." : ""),
      blocks,
      filesChanged: [...changed],
    });
    usePulse.getState().updateProject(opts.projectId, {
      status: hasFiles || mode === "chat" ? "ready" : "error",
      name: project.name,
    });

    if (mode === "agent") {
      const tasks = Object.keys(files).map((path) => ({
        id: uid("task"),
        title: `Write ${path}`,
        status: "done" as const,
      }));
      if (tasks.length) usePulse.getState().setTasks(opts.projectId, tasks);
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : "Agent failed";
    usePulse.getState().patchMessage(opts.projectId, assistantId, {
      content: prose || `Could not reach the model. ${message}`,
      blocks: [...blocks, { kind: "text", text: message }],
    });
    usePulse.getState().updateProject(opts.projectId, { status: "error" });
    throw err;
  }
}
