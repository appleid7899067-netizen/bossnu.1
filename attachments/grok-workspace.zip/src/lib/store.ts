import { create } from "zustand";
import { persist } from "zustand/middleware";
import type {
  BuildType,
  ChatMessage,
  FileMap,
  InteractionMode,
  Project,
  ProjectTask,
  PuterUser,
} from "./types";
import { titleFromPrompt, uid } from "./utils";
import { getPuter } from "./puter";

const KV_KEY = "pulse:projects:v1";

type Settings = {
  model: string;
  freeMode: boolean;
  seenLogin: boolean;
};

type PulseState = {
  ready: boolean;
  user: PuterUser | null;
  guest: boolean;
  settings: Settings;
  projects: Project[];
  setReady: (v: boolean) => void;
  setUser: (u: PuterUser | null) => void;
  setGuest: (v: boolean) => void;
  setSettings: (p: Partial<Settings>) => void;
  createProject: (input: {
    prompt: string;
    buildType: BuildType;
    mode: InteractionMode;
    model: string;
  }) => Project;
  updateProject: (id: string, patch: Partial<Project>) => void;
  appendMessage: (id: string, msg: ChatMessage) => void;
  patchMessage: (projectId: string, msgId: string, patch: Partial<ChatMessage>) => void;
  setFiles: (id: string, files: FileMap) => void;
  setTasks: (id: string, tasks: ProjectTask[]) => void;
  deleteProject: (id: string) => void;
  togglePin: (id: string) => void;
  project: (id: string) => Project | undefined;
  hydrateFromCloud: () => Promise<void>;
  persistCloud: () => Promise<void>;
};

export const usePulse = create<PulseState>()(
  persist(
    (set, get) => ({
      ready: true,
      user: null,
      guest: false,
      settings: { model: "auto", freeMode: false, seenLogin: false },
      projects: [],
      setReady: (ready) => set({ ready }),
      setUser: (user) => set({ user, guest: user ? false : get().guest }),
      setGuest: (guest) => set({ guest, settings: { ...get().settings, seenLogin: true } }),
      setSettings: (p) =>
        set({
          settings: { ...get().settings, ...p, seenLogin: true },
        }),
      createProject: ({ prompt, buildType, mode, model }) => {
        const now = Date.now();
        const project: Project = {
          id: uid("app"),
          name: titleFromPrompt(prompt),
          prompt,
          buildType,
          mode,
          status: "draft",
          pinned: false,
          createdAt: now,
          updatedAt: now,
          files: {},
          messages: [],
          tasks: [],
          model,
        };
        set({ projects: [project, ...get().projects] });
        void get().persistCloud();
        return project;
      },
      updateProject: (id, patch) => {
        set({
          projects: get().projects.map((p) =>
            p.id === id ? { ...p, ...patch, updatedAt: Date.now() } : p,
          ),
        });
        void get().persistCloud();
      },
      appendMessage: (id, msg) => {
        set({
          projects: get().projects.map((p) =>
            p.id === id
              ? { ...p, messages: [...p.messages, msg], updatedAt: Date.now() }
              : p,
          ),
        });
        void get().persistCloud();
      },
      patchMessage: (projectId, msgId, patch) => {
        set({
          projects: get().projects.map((p) =>
            p.id === projectId
              ? {
                  ...p,
                  messages: p.messages.map((m) =>
                    m.id === msgId ? { ...m, ...patch } : m,
                  ),
                  updatedAt: Date.now(),
                }
              : p,
          ),
        });
      },
      setFiles: (id, files) => {
        set({
          projects: get().projects.map((p) =>
            p.id === id ? { ...p, files, updatedAt: Date.now() } : p,
          ),
        });
        void get().persistCloud();
      },
      setTasks: (id, tasks) => {
        set({
          projects: get().projects.map((p) =>
            p.id === id ? { ...p, tasks, updatedAt: Date.now() } : p,
          ),
        });
      },
      deleteProject: (id) => {
        set({ projects: get().projects.filter((p) => p.id !== id) });
        void get().persistCloud();
      },
      togglePin: (id) => {
        set({
          projects: get().projects.map((p) =>
            p.id === id ? { ...p, pinned: !p.pinned } : p,
          ),
        });
        void get().persistCloud();
      },
      project: (id) => get().projects.find((p) => p.id === id),
      hydrateFromCloud: async () => {
        try {
          const puter = await getPuter();
          if (!puter.auth.isSignedIn()) return;
          const raw = await puter.kv.get(KV_KEY);
          if (!raw) return;
          const parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
          if (!parsed || typeof parsed !== "object") return;
          const cloud = (parsed as { projects?: Project[] }).projects;
          if (!Array.isArray(cloud) || cloud.length === 0) return;
          const local = get().projects;
          const byId = new Map(local.map((p) => [p.id, p]));
          for (const p of cloud) {
            const existing = byId.get(p.id);
            if (!existing || p.updatedAt > existing.updatedAt) byId.set(p.id, p);
          }
          const merged = [...byId.values()].sort((a, b) => b.updatedAt - a.updatedAt);
          set({ projects: merged });
        } catch {
          /* offline / not signed in */
        }
      },
      persistCloud: async () => {
        try {
          const puter = await getPuter();
          if (!puter.auth.isSignedIn()) return;
          await puter.kv.set(
            KV_KEY,
            JSON.stringify({
              projects: get().projects,
              savedAt: Date.now(),
            }),
          );
        } catch {
          /* ignore */
        }
      },
    }),
    {
      name: "pulse-local",
      partialize: (s) => ({
        projects: s.projects,
        settings: s.settings,
        guest: s.guest,
      }),
    },
  ),
);
