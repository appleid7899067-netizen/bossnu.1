import { createFileRoute } from "@tanstack/react-router";
import { Shell, Avatar } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { MODEL_OPTIONS } from "@/lib/models";
import { usePulse } from "@/lib/store";
import { currentPuterUser, puterSignIn, puterSignOut } from "@/lib/puter";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/account")({ component: AccountPage });

function AccountPage() {
  const user = usePulse((s) => s.user);
  const guest = usePulse((s) => s.guest);
  const settings = usePulse((s) => s.settings);
  const setSettings = usePulse((s) => s.setSettings);
  const setUser = usePulse((s) => s.setUser);
  const setGuest = usePulse((s) => s.setGuest);
  const projects = usePulse((s) => s.projects);

  async function signIn() {
    await puterSignIn();
    setUser(await currentPuterUser());
    await usePulse.getState().hydrateFromCloud();
  }

  async function signOut() {
    try {
      await puterSignOut();
    } catch {
      /* */
    }
    setUser(null);
    setGuest(false);
  }

  return (
    <Shell>
      <div className="px-5 pt-6 md:px-8 md:pt-8">
        <h1 className="text-2xl font-semibold tracking-tight">You</h1>

        <div className="mt-5 flex items-center gap-4 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <Avatar name={user?.username} />
          <div className="min-w-0 flex-1">
            <p className="truncate font-semibold">{user?.username ?? "Guest"}</p>
            <p className="truncate text-sm text-muted">
              {user?.email || (guest ? "Browsing as guest · Puter login for Agent" : "Puter account")}
            </p>
          </div>
        </div>

        {!user ? (
          <Button className="mt-4 w-full rounded-2xl" onClick={signIn}>
            Sign in with Puter
          </Button>
        ) : (
          <Button className="mt-4 w-full rounded-2xl" variant="secondary" onClick={signOut}>
            Sign out
          </Button>
        )}

        <section className="mt-8">
          <h2 className="text-xs font-medium tracking-wide text-subtle uppercase">Free Mode</h2>
          <button
            type="button"
            onClick={() => setSettings({ freeMode: !settings.freeMode })}
            className="mt-3 flex w-full items-center justify-between rounded-2xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]"
          >
            <div className="text-left">
              <p className="text-sm font-medium">Build without spending credits</p>
              <p className="mt-0.5 text-xs text-muted">Uses Puter test mode for Agent calls</p>
            </div>
            <span
              className={cn(
                "relative h-7 w-12 rounded-full transition-colors",
                settings.freeMode ? "bg-primary" : "bg-hover",
              )}
            >
              <span
                className={cn(
                  "absolute top-0.5 size-6 rounded-full bg-fg transition-transform",
                  settings.freeMode ? "translate-x-5" : "translate-x-0.5",
                )}
              />
            </span>
          </button>
        </section>

        <section className="mt-8">
          <h2 className="text-xs font-medium tracking-wide text-subtle uppercase">
            Intelligent model routing
          </h2>
          <p className="mt-1 text-sm text-muted">
            Auto picks a model from Puter’s catalog as the work gets simpler or harder.
          </p>
          <div className="mt-3 flex flex-col gap-1.5">
            {MODEL_OPTIONS.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setSettings({ model: m.id })}
                className={cn(
                  "rounded-2xl px-4 py-3 text-left shadow-[var(--shadow-border)]",
                  settings.model === m.id ? "bg-elevated ring-1 ring-primary/40" : "bg-surface",
                )}
              >
                <p className="text-sm font-medium">{m.label}</p>
                <p className="text-xs text-muted">{m.hint}</p>
              </button>
            ))}
          </div>
        </section>

        <p className="mt-8 text-xs text-subtle">
          {projects.length} app{projects.length === 1 ? "" : "s"} on this device
          {user ? " · synced to Puter KV" : ""}
        </p>
      </div>
    </Shell>
  );
}
