import type { ReactNode } from "react";
import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { PuterBoot } from "@/components/puter-boot";
import { LoginScreen } from "@/components/login-screen";
import { usePulse } from "@/lib/store";
import appCss from "../styles.css?url";

const APP_NAME = "Pulse";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      { name: "theme-color", content: "#0c0c0d" },
      {
        name: "description",
        content: "Pulse — vibe code with AI. Login and models via Puter.",
      },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap",
      },
    ],
  }),
  component: Root,
});

function Root() {
  return (
    <html lang="en" className="antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body className="bg-bg text-fg">
        <PreviewHostBridge />
        <AuthProvider>
          <PuterBoot />
          <Gate>
            <Outlet />
          </Gate>
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}

function Gate({ children }: { children: ReactNode }) {
  const ready = usePulse((s) => s.ready);
  const user = usePulse((s) => s.user);
  const guest = usePulse((s) => s.guest);
  const seen = usePulse((s) => s.settings.seenLogin);

  if (!ready) {
    return (
      <div className="grid min-h-dvh place-items-center bg-bg">
        <div className="size-8 animate-pulse rounded-xl bg-primary" />
      </div>
    );
  }
  if (!user && !guest && !seen) return <LoginScreen />;
  return <>{children}</>;
}
