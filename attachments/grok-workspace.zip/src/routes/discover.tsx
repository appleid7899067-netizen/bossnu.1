import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { STARTERS, BUILD_TYPES } from "@/lib/templates";
import { usePulse } from "@/lib/store";

export const Route = createFileRoute("/discover")({ component: DiscoverPage });

function DiscoverPage() {
  const navigate = useNavigate();
  const createProject = usePulse((s) => s.createProject);
  const model = usePulse((s) => s.settings.model);

  async function remix(id: string) {
    const s = STARTERS.find((x) => x.id === id);
    if (!s) return;
    const project = createProject({
      prompt: s.prompt,
      buildType: s.buildType,
      mode: "agent",
      model,
    });
    await navigate({ to: "/project/$id", params: { id: project.id } });
  }

  return (
    <Shell>
      <div className="px-5 pt-6 md:px-8 md:pt-8">
        <h1 className="text-2xl font-semibold tracking-tight">Discover</h1>
        <p className="mt-1 text-sm text-muted">Remix a template. Agent rebuilds it as yours.</p>
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          {STARTERS.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => remix(s.id)}
              className="rounded-[22px] bg-surface p-4 text-left shadow-[var(--shadow-border)] transition-colors hover:bg-elevated"
            >
              <p className="text-[11px] font-medium tracking-wide text-primary uppercase">
                {BUILD_TYPES.find((t) => t.id === s.buildType)?.label}
              </p>
              <h2 className="mt-2 text-[16px] font-semibold">{s.title}</h2>
              <p className="mt-1 text-sm text-muted">{s.blurb}</p>
              <p className="mt-3 text-xs text-subtle">{s.tone}</p>
            </button>
          ))}
        </div>
      </div>
    </Shell>
  );
}
