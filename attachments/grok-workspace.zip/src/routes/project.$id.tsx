import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Check,
  ChevronDown,
  Globe,
  Loader2,
  MoreHorizontal,
  PanelLeft,
} from "lucide-react";
import { AgentChat } from "@/components/agent-chat";
import { PromptBox } from "@/components/prompt-box";
import { PreviewFrame } from "@/components/preview-frame";
import { FileTree, CodePane } from "@/components/file-tree";
import { TasksPanel } from "@/components/tasks-panel";
import { Button } from "@/components/ui/button";
import { usePulse } from "@/lib/store";
import { runAgent } from "@/lib/agent";
import { getPuter, slugify } from "@/lib/puter";
import { fileList } from "@/lib/files";
import { cn } from "@/lib/utils";
import type { InteractionMode } from "@/lib/types";

export const Route = createFileRoute("/project/$id")({ component: ProjectPage });

type Pane = "agent" | "tools" | "tasks";

function ProjectPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const project = usePulse((s) => s.projects.find((p) => p.id === id));
  const updateProject = usePulse((s) => s.updateProject);
  const setFiles = usePulse((s) => s.setFiles);

  const [pane, setPane] = useState<Pane>("agent");
  const [showPreview, setShowPreview] = useState(false);
  const [draft, setDraft] = useState("");
  const [mode, setMode] = useState<InteractionMode>(project?.mode ?? "agent");
  const [busy, setBusy] = useState(false);
  const [activeFile, setActiveFile] = useState<string | null>(null);
  const [publishing, setPublishing] = useState(false);
  const [pubError, setPubError] = useState<string | null>(null);
  const [menu, setMenu] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);

  const openedPreview = useRef(false);

  useEffect(() => {
    if (!project) return;
    setMode(project.mode);
    const first = fileList(project.files)[0];
    if (first && !activeFile) setActiveFile(first);
    if (!openedPreview.current && Object.keys(project.files).length > 0) {
      openedPreview.current = true;
      setShowPreview(true);
    }
  }, [project, activeFile]);

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [project?.messages, busy]);

  const started = useRef(false);
  useEffect(() => {
    if (started.current) return;
    const current = usePulse.getState().project(id);
    if (!current || current.messages.length > 0 || !current.prompt.trim()) return;
    started.current = true;
    setBusy(true);
    runAgent({ projectId: id, userText: current.prompt })
      .catch(() => undefined)
      .finally(() => setBusy(false));
  }, [id]);

  if (!project) {
    return (
      <div className="grid min-h-dvh place-items-center bg-bg">
        <div className="text-center">
          <p className="font-medium">App not found</p>
          <Link to="/apps" className="mt-3 inline-block text-sm text-primary">
            Back to apps
          </Link>
        </div>
      </div>
    );
  }

  async function send() {
    const text = draft.trim();
    if (!text || busy) return;
    setDraft("");
    setBusy(true);
    updateProject(id, { mode });
    try {
      await runAgent({ projectId: id, userText: text });
    } catch {
      /* surfaced in thread */
    } finally {
      setBusy(false);
    }
  }

  async function publish() {
    if (!project) return;
    const current = project;
    setPublishing(true);
    setPubError(null);
    try {
      const puter = await getPuter();
      if (!puter.auth.isSignedIn()) {
        await puter.auth.signIn({ attempt_temp_user_creation: true });
      }
      const dir = `pulse-apps/${current.id}`;
      await puter.fs.mkdir(dir).catch(() => undefined);
      const entries = Object.entries(current.files);
      if (!entries.length) throw new Error("Nothing to publish yet");
      for (const [path, content] of entries) {
        await puter.fs.write(`${dir}/${path}`, content);
      }
      const sub = current.publishedSubdomain || slugify(current.name);
      let site: { subdomain: string };
      if (current.publishedSubdomain && puter.hosting.update) {
        await puter.hosting.update(current.publishedSubdomain, dir);
        site = { subdomain: current.publishedSubdomain };
      } else {
        site = await puter.hosting.create(sub, dir);
      }
      const url = `https://${site.subdomain}.puter.site`;
      updateProject(id, { publishedUrl: url, publishedSubdomain: site.subdomain });
    } catch (err) {
      setPubError(err instanceof Error ? err.message : "Publish failed");
    } finally {
      setPublishing(false);
    }
  }

  const building = busy || project.status === "building";
  const files = project.files;
  const openPath = activeFile && files[activeFile] != null ? activeFile : fileList(files)[0];

  return (
    <div className="flex h-dvh flex-col bg-bg">
      <header className="relative flex h-14 shrink-0 items-center gap-2 border-b border-border px-2 md:px-3">
        <button
          type="button"
          onClick={() => navigate({ to: "/" })}
          className="grid size-11 place-items-center rounded-xl text-muted hover:bg-hover hover:text-fg"
          aria-label="Back"
        >
          <ArrowLeft className="size-5" />
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">{project.name}</p>
          <p className="truncate text-[11px] text-subtle capitalize">
            {building ? "Agent running" : project.status} · {project.buildType}
          </p>
        </div>
        <Button
          size="sm"
          variant="secondary"
          className="rounded-full"
          onClick={publish}
          disabled={publishing || !Object.keys(files).length}
        >
          {publishing ? (
            <Loader2 className="size-3.5 animate-spin" />
          ) : project.publishedUrl ? (
            <Check className="size-3.5 text-success" />
          ) : (
            <Globe className="size-3.5" />
          )}
          {project.publishedUrl ? "Live" : "Publish"}
        </Button>
        <button
          type="button"
          className="grid size-11 place-items-center rounded-xl text-muted hover:bg-hover"
          onClick={() => setMenu((v) => !v)}
          aria-label="More"
        >
          <MoreHorizontal className="size-5" />
        </button>
        {menu ? (
          <div className="absolute top-12 right-3 z-30 w-56 overflow-hidden rounded-xl bg-elevated py-1 shadow-[var(--shadow-prompt)]">
            {project.publishedUrl ? (
              <a
                href={project.publishedUrl}
                target="_blank"
                rel="noreferrer"
                className="block px-3 py-2 text-sm hover:bg-hover"
              >
                Open live site
              </a>
            ) : null}
            <button
              type="button"
              className="block w-full px-3 py-2 text-left text-sm hover:bg-hover"
              onClick={() => {
                setPane("tools");
                setShowPreview(false);
                setMenu(false);
              }}
            >
              Open files
            </button>
          </div>
        ) : null}
      </header>

      {pubError ? (
        <div className="bg-danger/15 px-4 py-2 text-xs text-danger">{pubError}</div>
      ) : null}

      <div className="flex min-h-0 flex-1">
        <section className="flex min-h-0 min-w-0 flex-1 flex-col lg:max-w-md xl:max-w-lg lg:flex-none lg:border-r lg:border-border">
          <div className="flex shrink-0 justify-center gap-1 border-b border-border px-2 py-1.5">
            {(["agent", "tools", "tasks"] as const).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setPane(p)}
                className={cn(
                  "h-8 rounded-full px-3 text-xs font-medium capitalize",
                  pane === p ? "bg-elevated text-fg" : "text-muted",
                )}
              >
                {p}
              </button>
            ))}
          </div>

          {pane === "agent" ? (
            <>
              <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto">
                <AgentChat messages={project.messages} building={building} />
              </div>
              <div className="shrink-0 px-3 pb-2 pt-2">
                <PromptBox
                  value={draft}
                  onChange={setDraft}
                  onSubmit={send}
                  mode={mode}
                  onMode={(m) => {
                    setMode(m);
                    updateProject(id, { mode: m });
                  }}
                  compact
                  placeholder={mode === "chat" ? "Ask anything" : "Tell Agent what to change"}
                  disabled={busy}
                  busy={busy}
                />
              </div>
            </>
          ) : null}

          {pane === "tools" ? (
            <div className="flex min-h-0 flex-1">
              <div className="w-2/5 overflow-y-auto border-r border-border">
                <FileTree
                  files={files}
                  active={openPath}
                  onOpen={(p) => {
                    setActiveFile(p);
                    setShowPreview(false);
                  }}
                />
              </div>
              <div className="min-w-0 flex-1">
                {openPath ? (
                  <CodePane
                    path={openPath}
                    content={files[openPath] ?? ""}
                    onChange={(v) => setFiles(id, { ...files, [openPath]: v })}
                  />
                ) : (
                  <p className="p-6 text-sm text-subtle">No files yet</p>
                )}
              </div>
            </div>
          ) : null}

          {pane === "tasks" ? (
            <div className="min-h-0 flex-1 overflow-y-auto">
              <TasksPanel tasks={project.tasks} />
            </div>
          ) : null}
        </section>

        <section className="hidden min-h-0 min-w-0 flex-1 flex-col lg:flex">
          <div className="flex h-10 items-center gap-2 border-b border-border px-3 text-xs text-muted">
            <PanelLeft className="size-3.5" />
            Artifact
            <ChevronDown className="size-3" />
            <span className="ml-auto">Website</span>
          </div>
          <PreviewFrame files={files} buildType={project.buildType} className="min-h-0 flex-1" />
        </section>
      </div>

      <button
        type="button"
        onClick={() => setShowPreview((v) => !v)}
        className="flex h-12 shrink-0 items-center justify-between border-t border-border bg-surface px-4 text-sm lg:hidden"
      >
        <span className="flex items-center gap-2 font-medium">
          <Globe className="size-4 text-primary" />
          Website preview
        </span>
        <span className="text-xs text-subtle">{showPreview ? "Hide" : "Show"}</span>
      </button>

      {showPreview ? (
        <div className="h-[42vh] shrink-0 border-t border-border pb-[env(safe-area-inset-bottom)] lg:hidden">
          <PreviewFrame files={files} buildType={project.buildType} className="h-full" />
        </div>
      ) : (
        <div className="h-[env(safe-area-inset-bottom)] lg:hidden" />
      )}
    </div>
  );
}
