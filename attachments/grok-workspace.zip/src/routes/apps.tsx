import type { ReactNode } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Shell } from "@/components/shell";
import { ProjectCard } from "@/components/project-card";
import { BUILD_TYPES } from "@/lib/templates";
import { usePulse } from "@/lib/store";
import type { BuildType } from "@/lib/types";

export const Route = createFileRoute("/apps")({ component: AppsPage });

function AppsPage() {
  const projects = usePulse((s) => s.projects);
  const [q, setQ] = useState("");
  const [type, setType] = useState<BuildType | "all">("all");
  const [sort, setSort] = useState<"opened" | "name">("opened");

  const list = useMemo(() => {
    let rows = [...projects];
    if (type !== "all") rows = rows.filter((p) => p.buildType === type);
    if (q.trim()) {
      const s = q.toLowerCase();
      rows = rows.filter(
        (p) => p.name.toLowerCase().includes(s) || p.prompt.toLowerCase().includes(s),
      );
    }
    rows.sort((a, b) => {
      if (a.pinned !== b.pinned) return Number(b.pinned) - Number(a.pinned);
      if (sort === "name") return a.name.localeCompare(b.name);
      return b.updatedAt - a.updatedAt;
    });
    return rows;
  }, [projects, q, type, sort]);

  return (
    <Shell>
      <div className="px-5 pt-6 md:px-8 md:pt-8">
        <h1 className="text-2xl font-semibold tracking-tight">Apps</h1>
        <p className="mt-1 text-sm text-muted">Everything you’ve built in Pulse.</p>

        <div className="mt-5 flex items-center gap-2 rounded-2xl bg-surface px-3 shadow-[var(--shadow-border)]">
          <Search className="size-4 text-subtle" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search apps"
            className="h-12 w-full bg-transparent text-sm text-fg placeholder:text-subtle focus:outline-none"
          />
        </div>

        <div className="mt-3 flex gap-2 overflow-x-auto no-scrollbar">
          <Chip active={type === "all"} onClick={() => setType("all")}>
            Any type
          </Chip>
          {BUILD_TYPES.map((t) => (
            <Chip key={t.id} active={type === t.id} onClick={() => setType(t.id)}>
              {t.label}
            </Chip>
          ))}
        </div>

        <div className="mt-3 flex gap-2 text-xs">
          <button
            type="button"
            className={sort === "opened" ? "text-fg" : "text-subtle"}
            onClick={() => setSort("opened")}
          >
            Last opened
          </button>
          <span className="text-subtle">·</span>
          <button
            type="button"
            className={sort === "name" ? "text-fg" : "text-subtle"}
            onClick={() => setSort("name")}
          >
            Name
          </button>
        </div>

        {list.length === 0 ? (
          <div className="mt-16 text-center">
            <p className="text-sm font-medium">No apps yet</p>
            <p className="mt-1 text-sm text-muted">Describe something on Create and Agent will start.</p>
            <Link to="/" className="mt-4 inline-block text-sm font-medium text-primary">
              New app
            </Link>
          </div>
        ) : (
          <div className="mt-5 flex flex-col gap-2.5 pb-4">
            {list.map((p) => (
              <ProjectCard key={p.id} project={p} />
            ))}
          </div>
        )}
      </div>
    </Shell>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`h-8 shrink-0 rounded-full px-3 text-xs font-medium ${
        active ? "bg-primary text-primary-fg" : "bg-surface text-muted"
      }`}
    >
      {children}
    </button>
  );
}
