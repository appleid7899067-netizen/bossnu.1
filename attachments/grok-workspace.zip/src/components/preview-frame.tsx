import { useMemo } from "react";
import type { BuildType, FileMap } from "@/lib/types";
import { previewHtml } from "@/lib/files";
import { cn } from "@/lib/utils";

export function PreviewFrame({
  files,
  buildType,
  className,
}: {
  files: FileMap;
  buildType: BuildType;
  className?: string;
}) {
  const html = useMemo(() => previewHtml(files), [files]);
  const empty = Object.keys(files).length === 0;
  const phone = buildType === "mobile";

  if (empty) {
    return (
      <div
        className={cn(
          "grid h-full place-items-center bg-elevated text-sm text-subtle",
          className,
        )}
      >
        Preview appears after Agent writes files
      </div>
    );
  }

  const frame = (
    <iframe
      title="App preview"
      sandbox="allow-scripts allow-forms allow-modals allow-popups"
      srcDoc={html}
      className={cn(
        "h-full w-full border-0 bg-bg",
        phone ? "rounded-[2rem]" : "rounded-none",
      )}
    />
  );

  if (!phone) return <div className={cn("h-full w-full bg-bg", className)}>{frame}</div>;

  return (
    <div className={cn("grid h-full place-items-center bg-bg p-4", className)}>
      <div className="relative aspect-[9/19] h-full max-h-full w-auto max-w-[min(100%,380px)] rounded-[2.4rem] bg-black p-2 shadow-[var(--shadow-prompt)]">
        <div className="absolute top-3 left-1/2 z-10 h-5 w-24 -translate-x-1/2 rounded-full bg-black" />
        {frame}
      </div>
    </div>
  );
}
