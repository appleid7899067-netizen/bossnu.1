import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Compass, LayoutGrid, Plus, UserRound } from "lucide-react";
import { cn } from "@/lib/utils";
import { PulseMark } from "./logo";
import { usePulse } from "@/lib/store";

const TABS = [
  { to: "/", label: "Create", icon: Plus },
  { to: "/apps", label: "Apps", icon: LayoutGrid },
  { to: "/discover", label: "Discover", icon: Compass },
  { to: "/account", label: "You", icon: UserRound },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const user = usePulse((s) => s.user);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-56 flex-col border-r border-border bg-bg px-3 py-4 md:flex">
        <Link to="/" className="mb-6 flex items-center gap-2.5 px-2 pt-1">
          <PulseMark className="size-8" />
          <span className="text-[17px] font-semibold tracking-tight">Pulse</span>
        </Link>
        <nav className="flex flex-1 flex-col gap-1">
          {TABS.map((t) => {
            const active = t.to === "/" ? pathname === "/" : pathname.startsWith(t.to);
            return (
              <Link
                key={t.to}
                to={t.to}
                className={cn(
                  "flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium",
                  active ? "bg-elevated text-fg" : "text-muted hover:bg-hover hover:text-fg",
                )}
              >
                <t.icon className="size-4" />
                {t.label}
              </Link>
            );
          })}
        </nav>
        <Link
          to="/account"
          className="mt-auto flex items-center gap-3 rounded-xl px-2 py-2 hover:bg-hover"
        >
          <Avatar name={user?.username} />
          <div className="min-w-0">
            <div className="truncate text-sm font-medium">
              {user?.username ?? "Guest"}
            </div>
            <div className="text-xs text-subtle">Puter account</div>
          </div>
        </Link>
      </aside>

      <div className="md:pl-56">
        <div className="mx-auto min-h-dvh w-full max-w-5xl pb-24 md:pb-8">{children}</div>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-bg/92 backdrop-blur-md md:hidden">
        <div className="mx-auto grid max-w-lg grid-cols-4 px-2 pb-[env(safe-area-inset-bottom)]">
          {TABS.map((t) => {
            const active = t.to === "/" ? pathname === "/" : pathname.startsWith(t.to);
            return (
              <Link
                key={t.to}
                to={t.to}
                className={cn(
                  "flex min-h-14 flex-col items-center justify-center gap-1 text-[11px] font-medium",
                  active ? "text-fg" : "text-subtle",
                )}
              >
                <t.icon className={cn("size-5", active && "text-primary")} />
                {t.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

export function Avatar({ name, size = "md" }: { name?: string; size?: "sm" | "md" }) {
  const letter = (name || "P").slice(0, 1).toUpperCase();
  return (
    <span
      className={cn(
        "grid place-items-center rounded-full bg-primary font-semibold text-primary-fg",
        size === "sm" ? "size-8 text-xs" : "size-9 text-sm",
      )}
    >
      {letter}
    </span>
  );
}
