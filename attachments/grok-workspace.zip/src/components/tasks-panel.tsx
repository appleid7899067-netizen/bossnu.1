import { Check, Circle, Loader2 } from "lucide-react";
import type { ProjectTask } from "@/lib/types";

export function TasksPanel({ tasks }: { tasks: ProjectTask[] }) {
  if (!tasks.length) {
    return (
      <div className="grid h-full place-items-center px-6 text-center">
        <div>
          <p className="text-sm font-medium">No tasks yet</p>
          <p className="mt-1 text-sm text-muted">
            When Agent builds, each file write shows up here as a tracked task.
          </p>
        </div>
      </div>
    );
  }
  return (
    <ul className="flex flex-col gap-2 p-4">
      {tasks.map((t) => (
        <li
          key={t.id}
          className="flex items-start gap-3 rounded-2xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]"
        >
          <span className="mt-0.5 text-muted">
            {t.status === "done" ? (
              <Check className="size-4 text-success" />
            ) : t.status === "running" ? (
              <Loader2 className="size-4 animate-spin text-primary" />
            ) : (
              <Circle className="size-4" />
            )}
          </span>
          <div>
            <p className="text-sm font-medium">{t.title}</p>
            {t.detail ? <p className="mt-0.5 text-xs text-muted">{t.detail}</p> : null}
          </div>
        </li>
      ))}
    </ul>
  );
}
