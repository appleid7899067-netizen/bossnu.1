import { Link } from "@tanstack/react-router";
import { Globe, LayoutDashboard, MoreHorizontal, Pin, Smartphone, Sparkles, Trash2 } from "lucide-react";
import type { BuildType, Project } from "@/lib/types";
import { formatRelative } from "@/lib/utils";
import { usePulse } from "@/lib/store";
import { useState } from "react";

const ICONS: Record<BuildType, typeof Globe> = {
  web: Globe,
  mobile: Smartphone,
  slides: LayoutDashboard,
  dashboard: LayoutDashboard,
  video: Sparkles,
  other: Sparkles,
};

export function ProjectCard({ project }: { project: Project }) {
  const Icon = ICONS[project.buildType];
  const files = Object.keys(project.files).length;
  const [menu, setMenu] = useState(false);
  const togglePin = usePulse((s) => s.togglePin);
  const deleteProject = usePulse((s) => s.deleteProject);

  return (
    <div className="relative">
      <Link
        to="/project/$id"
        params={{ id: project.id }}
        className="block rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)] transition-[background-color,box-shadow] hover:bg-elevated"
      >
        <div className="flex items-start gap-3">
          <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-elevated text-muted">
            <Icon className="size-4.5" />
          </span>
          <div className="min-w-0 flex-1 pr-8">
            <div className="flex items-center gap-2">
              <h3 className="truncate text-[15px] font-semibold">{project.name}</h3>
              {project.pinned ? <Pin className="size-3 text-primary" /> : null}
            </div>
            <p className="mt-0.5 truncate text-sm text-muted">{project.prompt}</p>
            <div className="mt-3 flex items-center gap-2 text-xs text-subtle">
              <StatusDot status={project.status} />
              <span className="capitalize">{project.status}</span>
              <span>·</span>
              <span>{formatRelative(project.updatedAt)}</span>
              {files ? (
                <>
                  <span>·</span>
                  <span>
                    {files} file{files === 1 ? "" : "s"}
                  </span>
                </>
              ) : null}
            </div>
          </div>
        </div>
      </Link>
      <button
        type="button"
        className="absolute top-3 right-3 grid size-9 place-items-center rounded-lg text-subtle hover:bg-hover hover:text-fg"
        onClick={() => setMenu((v) => !v)}
        aria-label="Project menu"
      >
        <MoreHorizontal className="size-4" />
      </button>
      {menu ? (
        <div className="absolute top-12 right-3 z-10 w-40 overflow-hidden rounded-xl bg-elevated py-1 shadow-[var(--shadow-prompt)]">
          <button
            type="button"
            className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-hover"
            onClick={() => {
              togglePin(project.id);
              setMenu(false);
            }}
          >
            <Pin className="size-3.5" />
            {project.pinned ? "Unpin" : "Pin"}
          </button>
          <button
            type="button"
            className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-danger hover:bg-hover"
            onClick={() => {
              deleteProject(project.id);
              setMenu(false);
            }}
          >
            <Trash2 className="size-3.5" />
            Delete
          </button>
        </div>
      ) : null}
    </div>
  );
}

function StatusDot({ status }: { status: Project["status"] }) {
  const color =
    status === "building"
      ? "bg-primary"
      : status === "ready"
        ? "bg-success"
        : status === "error"
          ? "bg-danger"
          : "bg-subtle";
  return <span className={`size-1.5 rounded-full ${color}`} />;
}
