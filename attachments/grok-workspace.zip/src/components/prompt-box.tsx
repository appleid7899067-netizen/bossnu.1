import { useEffect, useRef, useState } from "react";
import { ArrowUp, Mic, Paperclip, Square } from "lucide-react";
import { cn } from "@/lib/utils";
import { BUILD_TYPES } from "@/lib/templates";
import type { BuildType, InteractionMode } from "@/lib/types";
import { Button } from "./ui/button";

type SpeechRec = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((ev: { results: { 0: { 0: { transcript: string } } } }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

export function PromptBox({
  value,
  onChange,
  onSubmit,
  mode,
  onMode,
  buildType,
  onBuildType,
  placeholder,
  compact,
  disabled,
  busy,
}: {
  value: string;
  onChange: (v: string) => void;
  onSubmit: () => void;
  mode: InteractionMode;
  onMode: (m: InteractionMode) => void;
  buildType?: BuildType;
  onBuildType?: (t: BuildType) => void;
  placeholder?: string;
  compact?: boolean;
  disabled?: boolean;
  busy?: boolean;
}) {
  const ta = useRef<HTMLTextAreaElement>(null);
  const [listening, setListening] = useState(false);
  const recRef = useRef<SpeechRec | null>(null);

  useEffect(() => {
    const el = ta.current;
    if (!el) return;
    el.style.height = "0px";
    el.style.height = `${Math.min(el.scrollHeight, compact ? 120 : 180)}px`;
  }, [value, compact]);

  function toggleVoice() {
    const SR =
      (window as unknown as { webkitSpeechRecognition?: new () => SpeechRec })
        .webkitSpeechRecognition ||
      (window as unknown as { SpeechRecognition?: new () => SpeechRec }).SpeechRecognition;
    if (!SR) return;
    if (listening) {
      recRef.current?.stop();
      setListening(false);
      return;
    }
    const rec = new SR();
    rec.lang = navigator.language || "en-US";
    rec.continuous = false;
    rec.interimResults = false;
    rec.onresult = (ev) => {
      const t = ev.results[0][0].transcript;
      onChange(value ? `${value} ${t}` : t);
    };
    rec.onend = () => setListening(false);
    recRef.current = rec;
    rec.start();
    setListening(true);
  }

  return (
    <div
      className={cn(
        "bg-surface shadow-[var(--shadow-prompt)]",
        compact ? "rounded-[22px] p-2" : "rounded-[28px] p-2.5",
      )}
    >
      {!compact && onBuildType && buildType ? (
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar px-1.5 pb-2 pt-1">
          {BUILD_TYPES.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => onBuildType(t.id)}
              className={cn(
                "h-8 shrink-0 rounded-full px-3 text-xs font-medium transition-colors",
                buildType === t.id
                  ? "bg-primary text-primary-fg"
                  : "bg-elevated text-muted hover:text-fg",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
      ) : null}

      <textarea
        ref={ta}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            if (value.trim() && !disabled && !busy) onSubmit();
          }
        }}
        rows={compact ? 1 : 3}
        placeholder={placeholder ?? "Describe what you want to make"}
        className={cn(
          "w-full resize-none bg-transparent px-3 py-2 text-[15px] leading-relaxed text-fg placeholder:text-subtle focus:outline-none",
          compact ? "min-h-11" : "min-h-[88px]",
        )}
      />

      <div className="flex items-center gap-1.5 px-1 pb-0.5">
        <button
          type="button"
          className="grid size-10 place-items-center rounded-xl text-muted hover:bg-hover hover:text-fg"
          aria-label="Attach"
        >
          <Paperclip className="size-4" />
        </button>
        <button
          type="button"
          onClick={toggleVoice}
          className={cn(
            "grid size-10 place-items-center rounded-xl",
            listening ? "bg-primary/15 text-primary" : "text-muted hover:bg-hover hover:text-fg",
          )}
          aria-label="Voice input"
        >
          <Mic className="size-4" />
        </button>

        <div className="ml-auto flex items-center gap-1.5">
          <div className="flex rounded-full bg-elevated p-0.5 shadow-[var(--shadow-border)]">
            {(["agent", "chat"] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => onMode(m)}
                className={cn(
                  "h-8 rounded-full px-3 text-xs font-medium capitalize",
                  mode === m ? "bg-hover text-fg" : "text-muted",
                )}
              >
                {m}
              </button>
            ))}
          </div>
          <Button
            size="icon"
            disabled={!value.trim() || disabled}
            onClick={onSubmit}
            aria-label={busy ? "Stop" : "Send"}
            className="rounded-full size-11"
          >
            {busy ? <Square className="size-3.5 fill-current" /> : <ArrowUp className="size-5" />}
          </Button>
        </div>
      </div>
    </div>
  );
}
