import { useEffect } from "react";
import { currentPuterUser, getPuter } from "@/lib/puter";
import { usePulse } from "@/lib/store";

export function PuterBoot() {
  const setUser = usePulse((s) => s.setUser);
  const setReady = usePulse((s) => s.setReady);

  useEffect(() => {
    setReady(true);
    let cancelled = false;
    (async () => {
      try {
        await getPuter();
        if (cancelled) return;
        const user = await currentPuterUser();
        if (cancelled || !user) return;
        setUser(user);
        await usePulse.getState().hydrateFromCloud();
      } catch {
        /* Agent still prompts Puter on first model call */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [setUser, setReady]);

  return null;
}
