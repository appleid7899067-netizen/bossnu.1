import { escapeHtml } from "@/lib/files";

export function Markdown({ text }: { text: string }) {
  if (!text) return null;
  const html = format(text);
  return (
    <div
      className="text-[15px] leading-relaxed text-fg/90 [&_a]:text-primary [&_code]:font-mono [&_code]:text-[13px] [&_code]:text-primary-fg/90 [&_code]:bg-elevated [&_code]:px-1 [&_code]:py-0.5 [&_code]:rounded-sm [&_p]:mb-3 [&_p:last-child]:mb-0 [&_ul]:mb-3 [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:mb-3 [&_ol]:list-decimal [&_ol]:pl-5 [&_h3]:font-semibold [&_h3]:mb-2 [&_pre]:bg-elevated [&_pre]:rounded-lg [&_pre]:p-3 [&_pre]:overflow-x-auto [&_pre]:text-[12px] [&_pre]:mb-3"
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}

function format(src: string): string {
  const parts = src.split(/(```[\s\S]*?```)/g);
  return parts
    .map((part) => {
      if (part.startsWith("```")) {
        const body = part.replace(/^```[\w.+-]*\n?/, "").replace(/```$/, "");
        return `<pre><code>${escapeHtml(body)}</code></pre>`;
      }
      let s = escapeHtml(part);
      s = s.replace(/^### (.*)$/gm, "<h3>$1</h3>");
      s = s.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
      s = s.replace(/`([^`]+)`/g, "<code>$1</code>");
      s = s.replace(/^\s*[-*] (.*)$/gm, "<li>$1</li>");
      s = s.replace(/(<li>.*<\/li>\n?)+/g, (m) => `<ul>${m}</ul>`);
      s = s
        .split(/\n{2,}/)
        .map((p) => (p.startsWith("<") ? p : `<p>${p.replace(/\n/g, "<br/>")}</p>`))
        .join("");
      return s;
    })
    .join("");
}
