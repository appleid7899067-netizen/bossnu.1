import type { ReactNode } from "react";
import { FileCode2, Loader2 } from "lucide-react";
import type { AgentBlock, ChatMessage } from "@/lib/types";
import { Markdown } from "./markdown";
import { cn } from "@/lib/utils";

export function AgentChat({
  messages,
  building,
}: {
  messages: ChatMessage[];
  building: boolean;
}) {
  return (
    <div className="flex flex-col gap-6 px-4 py-5 md:px-6">
      {messages.length === 0 ? (
        <p className="py-10 text-center text-sm text-subtle">
          Tell Agent what to build. It writes files, then the preview updates.
        </p>
      ) : null}
      {messages.map((m) => (
        <MessageBubble key={m.id} message={m} />
      ))}
      {building ? (
        <div className="flex items-center gap-2 text-sm text-muted">
          <Loader2 className="size-4 animate-spin text-primary" />
          Agent is working…
        </div>
      ) : null}
    </div>
  );
}

function MessageBubble({ message }: { message: ChatMessage }) {
  if (message.role === "user") {
    return (
      <div className="flex justify-end">
        <div className="max-w-[85%] rounded-[22px] rounded-br-md bg-elevated px-4 py-2.5 text-[15px] leading-relaxed shadow-[var(--shadow-border)]">
          {message.content}
        </div>
      </div>
    );
  }

  const files = (message.blocks ?? []).filter((b) => b.kind === "file") as Extract<
    AgentBlock,
    { kind: "file" }
  >[];
  const thinking = (message.blocks ?? []).find((b) => b.kind === "thinking");

  return (
    <div className="max-w-[92%]">
      {thinking && !message.content ? (
        <p className="mb-3 text-sm text-muted">{thinking.text}</p>
      ) : null}
      {files.length ? (
        <div className="mb-3 flex flex-col gap-1.5">
          {files.map((f, i) => (
            <div
              key={`${f.path}-${i}`}
              className="flex items-center gap-2 rounded-xl bg-surface px-3 py-2 text-sm shadow-[var(--shadow-border)]"
            >
              <FileCode2 className="size-3.5 text-primary" />
              <span className="font-medium">{f.action === "write" ? "Wrote" : f.action}</span>
              <span className="font-mono text-xs text-muted">{f.path}</span>
            </div>
          ))}
        </div>
      ) : null}
      <Markdown text={message.content} />
    </div>
  );
}

export function ChatScroller({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={cn("min-h-0 flex-1 overflow-y-auto", className)}>{children}</div>;
}
