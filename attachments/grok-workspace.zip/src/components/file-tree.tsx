import { FileCode2, Folder } from "lucide-react";
import { fileList } from "@/lib/files";
import type { FileMap } from "@/lib/types";
import { cn } from "@/lib/utils";

export function FileTree({
  files,
  active,
  onOpen,
}: {
  files: FileMap;
  active?: string;
  onOpen: (path: string) => void;
}) {
  const paths = fileList(files);
  if (!paths.length) {
    return <p className="px-4 py-8 text-sm text-subtle">No files yet.</p>;
  }
  return (
    <ul className="flex flex-col py-2">
      {paths.map((path) => (
        <li key={path}>
          <button
            type="button"
            onClick={() => onOpen(path)}
            className={cn(
              "flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm",
              active === path ? "bg-hover text-fg" : "text-muted hover:bg-hover hover:text-fg",
            )}
          >
            {path.includes("/") ? (
              <Folder className="size-3.5" />
            ) : (
              <FileCode2 className="size-3.5" />
            )}
            <span className="truncate font-mono text-[13px]">{path}</span>
          </button>
        </li>
      ))}
    </ul>
  );
}

export function CodePane({ path, content, onChange }: { path: string; content: string; onChange: (v: string) => void }) {
  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="border-b border-border px-4 py-2 font-mono text-xs text-muted">{path}</div>
      <textarea
        value={content}
        onChange={(e) => onChange(e.target.value)}
        spellCheck={false}
        className="min-h-0 flex-1 resize-none bg-bg px-4 py-3 font-mono text-[13px] leading-relaxed text-fg focus:outline-none"
      />
    </div>
  );
}
