import { useState } from "react";
import { PulseMark } from "./logo";
import { Button } from "./ui/button";
import { currentPuterUser, puterSignIn } from "@/lib/puter";
import { usePulse } from "@/lib/store";

export function LoginScreen() {
  const setUser = usePulse((s) => s.setUser);
  const setGuest = usePulse((s) => s.setGuest);
  const setSettings = usePulse((s) => s.setSettings);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function signIn() {
    setBusy(true);
    setError(null);
    try {
      await puterSignIn();
      const user = await currentPuterUser();
      setUser(user);
      setSettings({ seenLogin: true });
      await usePulse.getState().hydrateFromCloud();
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Sign in was blocked. Allow popups, then try again.",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative flex min-h-dvh flex-col items-center justify-center overflow-hidden bg-bg px-6">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-[420px] opacity-70"
        style={{
          background:
            "radial-gradient(ellipse 80% 60% at 50% -10%, rgba(242,98,7,0.22), transparent 60%)",
        }}
      />
      <div className="relative w-full max-w-sm text-center">
        <div className="mx-auto mb-8 grid size-16 place-items-center">
          <PulseMark className="size-16" />
        </div>
        <h1 className="text-[2rem] font-semibold tracking-tight">Pulse</h1>
        <p className="mt-2 text-[15px] leading-relaxed text-muted">
          Vibe code with AI. Describe an app, watch Agent build it, publish it
          from your phone.
        </p>

        <div className="mt-10 flex flex-col gap-3">
          <Button size="lg" className="w-full rounded-2xl" onClick={signIn} disabled={busy}>
            {busy ? "Opening Puter…" : "Continue with Puter"}
          </Button>
          <Button
            size="lg"
            variant="secondary"
            className="w-full rounded-2xl"
            onClick={() => setGuest(true)}
          >
            Continue as guest
          </Button>
        </div>
        {error ? <p className="mt-4 text-sm text-danger">{error}</p> : null}
        <p className="mt-8 text-xs leading-relaxed text-subtle">
          Login and models run on your Puter account. Pulse never stores API
          keys. Guest mode still uses Puter when Agent starts.
        </p>
      </div>
    </div>
  );
}
