//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bvez5QV8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/account",
			"/apps",
			"/discover",
			"/project/$id"
		],
		preloads: ["/assets/index-BHCiXU96.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BHCiXU96.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Blwd7XL9.js",
			"/assets/shell-B51ChYiq.js",
			"/assets/prompt-box-D672oYNZ.js",
			"/assets/project-card-D03wp1pe.js",
			"/assets/templates-A7NVYdsX.js",
			"/assets/agent-DH4MUUeJ.js"
		]
	},
	"/account": {
		filePath: "/workspace/src/routes/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-C3C8nzfQ.js",
			"/assets/shell-B51ChYiq.js",
			"/assets/models-BsLOLIKD.js"
		]
	},
	"/apps": {
		filePath: "/workspace/src/routes/apps.tsx",
		children: void 0,
		preloads: [
			"/assets/apps-dsDxN_Y7.js",
			"/assets/shell-B51ChYiq.js",
			"/assets/project-card-D03wp1pe.js",
			"/assets/templates-A7NVYdsX.js"
		]
	},
	"/discover": {
		filePath: "/workspace/src/routes/discover.tsx",
		children: void 0,
		preloads: [
			"/assets/discover-BvPkRGw4.js",
			"/assets/shell-B51ChYiq.js",
			"/assets/templates-A7NVYdsX.js",
			"/assets/agent-DH4MUUeJ.js"
		]
	},
	"/project/$id": {
		filePath: "/workspace/src/routes/project.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/project._id-l-fnY6yO.js",
			"/assets/prompt-box-D672oYNZ.js",
			"/assets/globe-BNJN-JAv.js",
			"/assets/agent-DH4MUUeJ.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
