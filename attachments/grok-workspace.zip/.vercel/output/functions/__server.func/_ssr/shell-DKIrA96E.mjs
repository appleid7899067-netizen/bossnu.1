import { C as require_jsx_runtime, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as Compass, c as Plus, m as LayoutGrid, t as UserRound } from "../_libs/lucide-react.mjs";
import { a as cn, h as usePulse, i as PulseMark } from "./router-zObRocos.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-DKIrA96E.js
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		to: "/",
		label: "Create",
		icon: Plus
	},
	{
		to: "/apps",
		label: "Apps",
		icon: LayoutGrid
	},
	{
		to: "/discover",
		label: "Discover",
		icon: Compass
	},
	{
		to: "/account",
		label: "You",
		icon: UserRound
	}
];
function Shell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const user = usePulse((s) => s.user);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-20 hidden w-56 flex-col border-r border-border bg-bg px-3 py-4 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "mb-6 flex items-center gap-2.5 px-2 pt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PulseMark, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[17px] font-semibold tracking-tight",
							children: "Pulse"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-col gap-1",
						children: TABS.map((t) => {
							const active = t.to === "/" ? pathname === "/" : pathname.startsWith(t.to);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: t.to,
								className: cn("flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium", active ? "bg-elevated text-fg" : "text-muted hover:bg-hover hover:text-fg"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: "size-4" }), t.label]
							}, t.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/account",
						className: "mt-auto flex items-center gap-3 rounded-xl px-2 py-2 hover:bg-hover",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name: user?.username }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm font-medium",
								children: user?.username ?? "Guest"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-subtle",
								children: "Puter account"
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:pl-56",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto min-h-dvh w-full max-w-5xl pb-24 md:pb-8",
					children
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-border bg-bg/92 backdrop-blur-md md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-lg grid-cols-4 px-2 pb-[env(safe-area-inset-bottom)]",
					children: TABS.map((t) => {
						const active = t.to === "/" ? pathname === "/" : pathname.startsWith(t.to);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: t.to,
							className: cn("flex min-h-14 flex-col items-center justify-center gap-1 text-[11px] font-medium", active ? "text-fg" : "text-subtle"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: cn("size-5", active && "text-primary") }), t.label]
						}, t.to);
					})
				})
			})
		]
	});
}
function Avatar({ name, size = "md" }) {
	const letter = (name || "P").slice(0, 1).toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid place-items-center rounded-full bg-primary font-semibold text-primary-fg", size === "sm" ? "size-8 text-xs" : "size-9 text-sm"),
		children: letter
	});
}
//#endregion
export { Shell as n, Avatar as t };
