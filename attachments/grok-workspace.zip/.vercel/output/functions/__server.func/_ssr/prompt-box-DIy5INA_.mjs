import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as Mic, i as Square, u as Paperclip, w as ArrowUp } from "../_libs/lucide-react.mjs";
import { a as cn, r as Button } from "./router-zObRocos.mjs";
import { t as BUILD_TYPES } from "./templates-B1GF2m3y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/prompt-box-DIy5INA_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PromptBox({ value, onChange, onSubmit, mode, onMode, buildType, onBuildType, placeholder, compact, disabled, busy }) {
	const ta = (0, import_react.useRef)(null);
	const [listening, setListening] = (0, import_react.useState)(false);
	const recRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ta.current;
		if (!el) return;
		el.style.height = "0px";
		el.style.height = `${Math.min(el.scrollHeight, compact ? 120 : 180)}px`;
	}, [value, compact]);
	function toggleVoice() {
		const SR = window.webkitSpeechRecognition || window.SpeechRecognition;
		if (!SR) return;
		if (listening) {
			recRef.current?.stop();
			setListening(false);
			return;
		}
		const rec = new SR();
		rec.lang = navigator.language || "en-US";
		rec.continuous = false;
		rec.interimResults = false;
		rec.onresult = (ev) => {
			const t = ev.results[0][0].transcript;
			onChange(value ? `${value} ${t}` : t);
		};
		rec.onend = () => setListening(false);
		recRef.current = rec;
		rec.start();
		setListening(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("bg-surface shadow-[var(--shadow-prompt)]", compact ? "rounded-[22px] p-2" : "rounded-[28px] p-2.5"),
		children: [
			!compact && onBuildType && buildType ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1.5 overflow-x-auto no-scrollbar px-1.5 pb-2 pt-1",
				children: BUILD_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onBuildType(t.id),
					className: cn("h-8 shrink-0 rounded-full px-3 text-xs font-medium transition-colors", buildType === t.id ? "bg-primary text-primary-fg" : "bg-elevated text-muted hover:text-fg"),
					children: t.label
				}, t.id))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				ref: ta,
				value,
				disabled,
				onChange: (e) => onChange(e.target.value),
				onKeyDown: (e) => {
					if (e.key === "Enter" && !e.shiftKey) {
						e.preventDefault();
						if (value.trim() && !disabled && !busy) onSubmit();
					}
				},
				rows: compact ? 1 : 3,
				placeholder: placeholder ?? "Describe what you want to make",
				className: cn("w-full resize-none bg-transparent px-3 py-2 text-[15px] leading-relaxed text-fg placeholder:text-subtle focus:outline-none", compact ? "min-h-11" : "min-h-[88px]")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1.5 px-1 pb-0.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center rounded-xl text-muted hover:bg-hover hover:text-fg",
						"aria-label": "Attach",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: toggleVoice,
						className: cn("grid size-10 place-items-center rounded-xl", listening ? "bg-primary/15 text-primary" : "text-muted hover:bg-hover hover:text-fg"),
						"aria-label": "Voice input",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex rounded-full bg-elevated p-0.5 shadow-[var(--shadow-border)]",
							children: ["agent", "chat"].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onMode(m),
								className: cn("h-8 rounded-full px-3 text-xs font-medium capitalize", mode === m ? "bg-hover text-fg" : "text-muted"),
								children: m
							}, m))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							disabled: !value.trim() || disabled,
							onClick: onSubmit,
							"aria-label": busy ? "Stop" : "Send",
							className: "rounded-full size-11",
							children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-3.5 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-5" })
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { PromptBox as t };
