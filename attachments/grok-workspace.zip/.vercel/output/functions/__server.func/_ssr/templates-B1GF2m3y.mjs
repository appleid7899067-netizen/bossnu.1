//#region node_modules/.nitro/vite/services/ssr/assets/templates-B1GF2m3y.js
var STARTERS = [
	{
		id: "portfolio",
		title: "Personal portfolio",
		blurb: "A cinematic site for your work",
		buildType: "web",
		tone: "Editorial dark",
		prompt: "Build a personal portfolio website for a product designer named Mira Chen. Dark editorial look, large photography-style project cards, a case-study page for an airline rebrand, smooth page transitions, and a contact form. Distinctive, not generic."
	},
	{
		id: "booking",
		title: "Booking site",
		blurb: "Warm studio with real dates",
		buildType: "web",
		tone: "Warm serif",
		prompt: "Build a booking website for a small photography studio. Warm, soft, slightly faded colors, a serif with weight, a gallery, and a calendar where clients can pick real dates and leave a request. Mobile-first, beautiful empty states."
	},
	{
		id: "habit",
		title: "Habit tracker",
		blurb: "One-handed daily streaks",
		buildType: "mobile",
		tone: "Calm fitness",
		prompt: "Build a phone-first habit tracker. Users add habits, check them off today, see a 7-day streak heatmap, and get a quiet end-of-day summary. Large tap targets, one-handed use, dark theme with a single orange accent."
	},
	{
		id: "dashboard",
		title: "Sales dashboard",
		blurb: "KPIs, charts, live filters",
		buildType: "dashboard",
		tone: "Dense product",
		prompt: "Build a sales analytics dashboard with KPI cards (revenue, conversion, churn), a 12-week revenue area chart, a regional table, and filters for date range and channel. Use realistic sample data. Dark, dense, product-grade."
	},
	{
		id: "slides",
		title: "Pitch deck",
		blurb: "Eight slides, keyboard nav",
		buildType: "slides",
		tone: "Bold type",
		prompt: "Build an 8-slide pitch deck for Pulse, an AI vibe-coding app. Keyboard arrows and dots to navigate. Huge type, one idea per slide, orange on near-black. Cover, problem, product, demo, market, business, team, ask."
	},
	{
		id: "todo",
		title: "Family todo",
		blurb: "Shared lists that feel human",
		buildType: "web",
		tone: "Soft paper",
		prompt: "Build a family todo app with lists, due dates, assignees with color dots, and a today view. Soft paper light theme, delightful check-off animation, local persistence. No stock purple SaaS look."
	},
	{
		id: "menu",
		title: "Restaurant menu",
		blurb: "Night market energy",
		buildType: "mobile",
		tone: "Night market",
		prompt: "Build a mobile restaurant menu for a Thai night-market stall called Larb Fire. Categories, spicy indicators, cart, and checkout note to the stall. Dark with chili-red accents, big food names in Thai and English."
	},
	{
		id: "quiz",
		title: "Trivia night",
		blurb: "Timed questions, score pop",
		buildType: "web",
		tone: "Game-show",
		prompt: "Build a trivia night web app. 10 questions, 15-second timer, four answers, score, and a results screen with shareable summary. Snappy motion, high contrast, no emoji clutter."
	}
];
var BUILD_TYPES = [
	{
		id: "web",
		label: "Website"
	},
	{
		id: "mobile",
		label: "Mobile app"
	},
	{
		id: "slides",
		label: "Slides"
	},
	{
		id: "dashboard",
		label: "Dashboard"
	},
	{
		id: "video",
		label: "Video"
	},
	{
		id: "other",
		label: "Other"
	}
];
//#endregion
export { STARTERS as n, BUILD_TYPES as t };
