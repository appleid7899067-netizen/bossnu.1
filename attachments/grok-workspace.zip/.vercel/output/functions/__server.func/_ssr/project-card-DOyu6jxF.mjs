import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Sparkles, g as Globe, h as LayoutDashboard, l as Pin, o as Smartphone, r as Trash2, y as Ellipsis } from "../_libs/lucide-react.mjs";
import { h as usePulse, l as formatRelative } from "./router-zObRocos.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/project-card-DOyu6jxF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	web: Globe,
	mobile: Smartphone,
	slides: LayoutDashboard,
	dashboard: LayoutDashboard,
	video: Sparkles,
	other: Sparkles
};
function ProjectCard({ project }) {
	const Icon = ICONS[project.buildType];
	const files = Object.keys(project.files).length;
	const [menu, setMenu] = (0, import_react.useState)(false);
	const togglePin = usePulse((s) => s.togglePin);
	const deleteProject = usePulse((s) => s.deleteProject);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/project/$id",
				params: { id: project.id },
				className: "block rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)] transition-[background-color,box-shadow] hover:bg-elevated",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-10 shrink-0 place-items-center rounded-xl bg-elevated text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4.5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1 pr-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "truncate text-[15px] font-semibold",
									children: project.name
								}), project.pinned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "size-3 text-primary" }) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-0.5 truncate text-sm text-muted",
								children: project.prompt
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex items-center gap-2 text-xs text-subtle",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusDot, { status: project.status }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "capitalize",
										children: project.status
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatRelative(project.updatedAt) }),
									files ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										files,
										" file",
										files === 1 ? "" : "s"
									] })] }) : null
								]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "absolute top-3 right-3 grid size-9 place-items-center rounded-lg text-subtle hover:bg-hover hover:text-fg",
				onClick: () => setMenu((v) => !v),
				"aria-label": "Project menu",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
			}),
			menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute top-12 right-3 z-10 w-40 overflow-hidden rounded-xl bg-elevated py-1 shadow-[var(--shadow-prompt)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-hover",
					onClick: () => {
						togglePin(project.id);
						setMenu(false);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "size-3.5" }), project.pinned ? "Unpin" : "Pin"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-danger hover:bg-hover",
					onClick: () => {
						deleteProject(project.id);
						setMenu(false);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), "Delete"]
				})]
			}) : null
		]
	});
}
function StatusDot({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-1.5 rounded-full ${status === "building" ? "bg-primary" : status === "ready" ? "bg-success" : status === "error" ? "bg-danger" : "bg-subtle"}` });
}
//#endregion
export { ProjectCard as t };
