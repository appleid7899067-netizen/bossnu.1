import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Check, S as ChevronDown, T as ArrowLeft, _ as Folder, d as PanelLeft, g as Globe, p as LoaderCircle, v as FileCode2, x as Circle, y as Ellipsis } from "../_libs/lucide-react.mjs";
import { a as cn, h as usePulse, n as Route, p as slugify, r as Button, u as getPuter } from "./router-zObRocos.mjs";
import { i as runAgent, n as fileList, r as previewHtml, t as escapeHtml } from "./agent-kJQiei1d.mjs";
import { t as PromptBox } from "./prompt-box-DIy5INA_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/project._id-DKn6gKxC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Markdown({ text }) {
	if (!text) return null;
	const html = format(text);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-[15px] leading-relaxed text-fg/90 [&_a]:text-primary [&_code]:font-mono [&_code]:text-[13px] [&_code]:text-primary-fg/90 [&_code]:bg-elevated [&_code]:px-1 [&_code]:py-0.5 [&_code]:rounded-sm [&_p]:mb-3 [&_p:last-child]:mb-0 [&_ul]:mb-3 [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:mb-3 [&_ol]:list-decimal [&_ol]:pl-5 [&_h3]:font-semibold [&_h3]:mb-2 [&_pre]:bg-elevated [&_pre]:rounded-lg [&_pre]:p-3 [&_pre]:overflow-x-auto [&_pre]:text-[12px] [&_pre]:mb-3",
		dangerouslySetInnerHTML: { __html: html }
	});
}
function format(src) {
	return src.split(/(```[\s\S]*?```)/g).map((part) => {
		if (part.startsWith("```")) {
			const body = part.replace(/^```[\w.+-]*\n?/, "").replace(/```$/, "");
			return `<pre><code>${escapeHtml(body)}</code></pre>`;
		}
		let s = escapeHtml(part);
		s = s.replace(/^### (.*)$/gm, "<h3>$1</h3>");
		s = s.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
		s = s.replace(/`([^`]+)`/g, "<code>$1</code>");
		s = s.replace(/^\s*[-*] (.*)$/gm, "<li>$1</li>");
		s = s.replace(/(<li>.*<\/li>\n?)+/g, (m) => `<ul>${m}</ul>`);
		s = s.split(/\n{2,}/).map((p) => p.startsWith("<") ? p : `<p>${p.replace(/\n/g, "<br/>")}</p>`).join("");
		return s;
	}).join("");
}
function AgentChat({ messages, building }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6 px-4 py-5 md:px-6",
		children: [
			messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-10 text-center text-sm text-subtle",
				children: "Tell Agent what to build. It writes files, then the preview updates."
			}) : null,
			messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageBubble, { message: m }, m.id)),
			building ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-primary" }), "Agent is working…"]
			}) : null
		]
	});
}
function MessageBubble({ message }) {
	if (message.role === "user") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex justify-end",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "max-w-[85%] rounded-[22px] rounded-br-md bg-elevated px-4 py-2.5 text-[15px] leading-relaxed shadow-[var(--shadow-border)]",
			children: message.content
		})
	});
	const files = (message.blocks ?? []).filter((b) => b.kind === "file");
	const thinking = (message.blocks ?? []).find((b) => b.kind === "thinking");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-[92%]",
		children: [
			thinking && !message.content ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-muted",
				children: thinking.text
			}) : null,
			files.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 flex flex-col gap-1.5",
				children: files.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-xl bg-surface px-3 py-2 text-sm shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCode2, { className: "size-3.5 text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: f.action === "write" ? "Wrote" : f.action
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-muted",
							children: f.path
						})
					]
				}, `${f.path}-${i}`))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Markdown, { text: message.content })
		]
	});
}
function PreviewFrame({ files, buildType, className }) {
	const html = (0, import_react.useMemo)(() => previewHtml(files), [files]);
	const empty = Object.keys(files).length === 0;
	const phone = buildType === "mobile";
	if (empty) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("grid h-full place-items-center bg-elevated text-sm text-subtle", className),
		children: "Preview appears after Agent writes files"
	});
	const frame = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
		title: "App preview",
		sandbox: "allow-scripts allow-forms allow-modals allow-popups",
		srcDoc: html,
		className: cn("h-full w-full border-0 bg-bg", phone ? "rounded-[2rem]" : "rounded-none")
	});
	if (!phone) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("h-full w-full bg-bg", className),
		children: frame
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("grid h-full place-items-center bg-bg p-4", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-[9/19] h-full max-h-full w-auto max-w-[min(100%,380px)] rounded-[2.4rem] bg-black p-2 shadow-[var(--shadow-prompt)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-3 left-1/2 z-10 h-5 w-24 -translate-x-1/2 rounded-full bg-black" }), frame]
		})
	});
}
function FileTree({ files, active, onOpen }) {
	const paths = fileList(files);
	if (!paths.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-4 py-8 text-sm text-subtle",
		children: "No files yet."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col py-2",
		children: paths.map((path) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onOpen(path),
			className: cn("flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm", active === path ? "bg-hover text-fg" : "text-muted hover:bg-hover hover:text-fg"),
			children: [path.includes("/") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Folder, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCode2, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate font-mono text-[13px]",
				children: path
			})]
		}) }, path))
	});
}
function CodePane({ path, content, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-b border-border px-4 py-2 font-mono text-xs text-muted",
			children: path
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			value: content,
			onChange: (e) => onChange(e.target.value),
			spellCheck: false,
			className: "min-h-0 flex-1 resize-none bg-bg px-4 py-3 font-mono text-[13px] leading-relaxed text-fg focus:outline-none"
		})]
	});
}
function TasksPanel({ tasks }) {
	if (!tasks.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-full place-items-center px-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium",
			children: "No tasks yet"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "When Agent builds, each file write shows up here as a tracked task."
		})] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2 p-4",
		children: tasks.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-start gap-3 rounded-2xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 text-muted",
				children: t.status === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-success" }) : t.status === "running" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-primary" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "size-4" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: t.title
			}), t.detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-xs text-muted",
				children: t.detail
			}) : null] })]
		}, t.id))
	});
}
function ProjectPage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const project = usePulse((s) => s.projects.find((p) => p.id === id));
	const updateProject = usePulse((s) => s.updateProject);
	const setFiles = usePulse((s) => s.setFiles);
	const [pane, setPane] = (0, import_react.useState)("agent");
	const [showPreview, setShowPreview] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [mode, setMode] = (0, import_react.useState)(project?.mode ?? "agent");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [activeFile, setActiveFile] = (0, import_react.useState)(null);
	const [publishing, setPublishing] = (0, import_react.useState)(false);
	const [pubError, setPubError] = (0, import_react.useState)(null);
	const [menu, setMenu] = (0, import_react.useState)(false);
	const scroller = (0, import_react.useRef)(null);
	const openedPreview = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!project) return;
		setMode(project.mode);
		const first = fileList(project.files)[0];
		if (first && !activeFile) setActiveFile(first);
		if (!openedPreview.current && Object.keys(project.files).length > 0) {
			openedPreview.current = true;
			setShowPreview(true);
		}
	}, [project, activeFile]);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (!el) return;
		el.scrollTop = el.scrollHeight;
	}, [project?.messages, busy]);
	if (!project) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "App not found"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/apps",
				className: "mt-3 inline-block text-sm text-primary",
				children: "Back to apps"
			})]
		})
	});
	async function send() {
		const text = draft.trim();
		if (!text || busy) return;
		setDraft("");
		setBusy(true);
		updateProject(id, { mode });
		try {
			await runAgent({
				projectId: id,
				userText: text
			});
		} catch {} finally {
			setBusy(false);
		}
	}
	async function publish() {
		if (!project) return;
		const current = project;
		setPublishing(true);
		setPubError(null);
		try {
			const puter = await getPuter();
			if (!puter.auth.isSignedIn()) await puter.auth.signIn({ attempt_temp_user_creation: true });
			const dir = `pulse-apps/${current.id}`;
			await puter.fs.mkdir(dir).catch(() => void 0);
			const entries = Object.entries(current.files);
			if (!entries.length) throw new Error("Nothing to publish yet");
			for (const [path, content] of entries) await puter.fs.write(`${dir}/${path}`, content);
			const sub = current.publishedSubdomain || slugify(current.name);
			let site;
			if (current.publishedSubdomain && puter.hosting.update) {
				await puter.hosting.update(current.publishedSubdomain, dir);
				site = { subdomain: current.publishedSubdomain };
			} else site = await puter.hosting.create(sub, dir);
			const url = `https://${site.subdomain}.puter.site`;
			updateProject(id, {
				publishedUrl: url,
				publishedSubdomain: site.subdomain
			});
		} catch (err) {
			setPubError(err instanceof Error ? err.message : "Publish failed");
		} finally {
			setPublishing(false);
		}
	}
	const building = busy || project.status === "building";
	const files = project.files;
	const openPath = activeFile && files[activeFile] != null ? activeFile : fileList(files)[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative flex h-14 shrink-0 items-center gap-2 border-b border-border px-2 md:px-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => navigate({ to: "/" }),
						className: "grid size-11 place-items-center rounded-xl text-muted hover:bg-hover hover:text-fg",
						"aria-label": "Back",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-semibold",
							children: project.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-[11px] text-subtle capitalize",
							children: [
								building ? "Agent running" : project.status,
								" · ",
								project.buildType
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "secondary",
						className: "rounded-full",
						onClick: publish,
						disabled: publishing || !Object.keys(files).length,
						children: [publishing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }) : project.publishedUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-success" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-3.5" }), project.publishedUrl ? "Live" : "Publish"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center rounded-xl text-muted hover:bg-hover",
						onClick: () => setMenu((v) => !v),
						"aria-label": "More",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-5" })
					}),
					menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute top-12 right-3 z-30 w-56 overflow-hidden rounded-xl bg-elevated py-1 shadow-[var(--shadow-prompt)]",
						children: [project.publishedUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: project.publishedUrl,
							target: "_blank",
							rel: "noreferrer",
							className: "block px-3 py-2 text-sm hover:bg-hover",
							children: "Open live site"
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "block w-full px-3 py-2 text-left text-sm hover:bg-hover",
							onClick: () => {
								setPane("tools");
								setShowPreview(false);
								setMenu(false);
							},
							children: "Open files"
						})]
					}) : null
				]
			}),
			pubError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-danger/15 px-4 py-2 text-xs text-danger",
				children: pubError
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-h-0 min-w-0 flex-1 flex-col lg:max-w-md xl:max-w-lg lg:flex-none lg:border-r lg:border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex shrink-0 justify-center gap-1 border-b border-border px-2 py-1.5",
							children: [
								"agent",
								"tools",
								"tasks"
							].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPane(p),
								className: cn("h-8 rounded-full px-3 text-xs font-medium capitalize", pane === p ? "bg-elevated text-fg" : "text-muted"),
								children: p
							}, p))
						}),
						pane === "agent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: scroller,
							className: "min-h-0 flex-1 overflow-y-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentChat, {
								messages: project.messages,
								building
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "shrink-0 px-3 pb-2 pt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptBox, {
								value: draft,
								onChange: setDraft,
								onSubmit: send,
								mode,
								onMode: (m) => {
									setMode(m);
									updateProject(id, { mode: m });
								},
								compact: true,
								placeholder: mode === "chat" ? "Ask anything" : "Tell Agent what to change",
								disabled: busy,
								busy
							})
						})] }) : null,
						pane === "tools" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-h-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-2/5 overflow-y-auto border-r border-border",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileTree, {
									files,
									active: openPath,
									onOpen: (p) => {
										setActiveFile(p);
										setShowPreview(false);
									}
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "min-w-0 flex-1",
								children: openPath ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodePane, {
									path: openPath,
									content: files[openPath] ?? "",
									onChange: (v) => setFiles(id, {
										...files,
										[openPath]: v
									})
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "p-6 text-sm text-subtle",
									children: "No files yet"
								})
							})]
						}) : null,
						pane === "tasks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-h-0 flex-1 overflow-y-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TasksPanel, { tasks: project.tasks })
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "hidden min-h-0 min-w-0 flex-1 flex-col lg:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-10 items-center gap-2 border-b border-border px-3 text-xs text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeft, { className: "size-3.5" }),
							"Artifact",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto",
								children: "Website"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewFrame, {
						files,
						buildType: project.buildType,
						className: "min-h-0 flex-1"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setShowPreview((v) => !v),
				className: "flex h-12 shrink-0 items-center justify-between border-t border-border bg-surface px-4 text-sm lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2 font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-4 text-primary" }), "Website preview"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-subtle",
					children: showPreview ? "Hide" : "Show"
				})]
			}),
			showPreview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-[42vh] shrink-0 border-t border-border pb-[env(safe-area-inset-bottom)] lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewFrame, {
					files,
					buildType: project.buildType,
					className: "h-full"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[env(safe-area-inset-bottom)] lg:hidden" })
		]
	});
}
//#endregion
export { ProjectPage as component };
