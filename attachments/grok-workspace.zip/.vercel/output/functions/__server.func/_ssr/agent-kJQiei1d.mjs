import { c as extractToolCalls, h as usePulse, m as uid, o as consumeChat, u as getPuter } from "./router-zObRocos.mjs";
import { n as routeModel } from "./models-B4ceBp4S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/agent-kJQiei1d.js
var FENCE = /(?:^|\n)(?:===FILE:\s*([^\n=]+?)===|```(?:[\w.+-]+)?(?:\s+([\w./-]+))?\s*\n)([\s\S]*?)(?:\n===END===|\n```)/g;
function parseFilesFromText(text) {
	const files = {};
	const re = new RegExp(FENCE.source, "g");
	let m;
	while (m = re.exec(text)) {
		const named = (m[1] || m[2] || "").trim().replace(/^\/+/, "");
		const body = m[3]?.replace(/\n$/, "") ?? "";
		if (!named || !body.trim()) continue;
		files[named] = body;
	}
	if (Object.keys(files).length === 0) {
		const html = text.match(/<!DOCTYPE html>[\s\S]*<\/html>/i)?.[0];
		if (html) files["index.html"] = html;
	}
	return files;
}
function mergeFiles(base, next) {
	return {
		...base,
		...next
	};
}
function previewHtml(files) {
	const index = files["index.html"] || files["index.htm"] || Object.entries(files).find(([k]) => k.endsWith(".html"))?.[1];
	if (index) {
		let html = index;
		const css = collect(files, (k) => k.endsWith(".css") && k !== "index.html");
		const js = collect(files, (k) => k.endsWith(".js") && !k.endsWith(".json"));
		if (css && !/<link[^>]+stylesheet/i.test(html) && !/<style/i.test(html)) {
			html = html.replace("</head>", `<style>${css}</style></head>`);
			if (!html.includes("</head>")) html = `<style>${css}</style>` + html;
		}
		if (js && !/<script/i.test(html)) {
			html = html.replace("</body>", `<script>${js}<\/script></body>`);
			if (!html.includes("</body>")) html += `<script>${js}<\/script>`;
		}
		return html;
	}
	const md = files["README.md"] || files["readme.md"];
	if (md) return wrapDoc(`<pre style="white-space:pre-wrap;font:14px/1.5 ui-monospace,monospace">${escapeHtml(md)}</pre>`);
	const first = Object.entries(files)[0];
	if (!first) return wrapDoc(`<div style="height:100%;display:grid;place-items:center;color:#71717a;font-family:system-ui">Nothing to preview yet</div>`);
	return wrapDoc(`<pre style="white-space:pre-wrap;font:13px/1.5 ui-monospace,monospace;padding:24px">${escapeHtml(first[1])}</pre>`);
}
function collect(files, pred) {
	return Object.entries(files).filter(([k]) => pred(k)).map(([, v]) => v).join("\n\n");
}
function wrapDoc(body) {
	return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;height:100%;background:#0c0c0d;color:#f4f4f5}</style></head><body>${body}</body></html>`;
}
function escapeHtml(s) {
	return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function fileList(files) {
	return Object.keys(files).sort((a, b) => {
		if (a === "index.html") return -1;
		if (b === "index.html") return 1;
		return a.localeCompare(b);
	});
}
var AGENT_TOOLS = [
	{
		type: "function",
		function: {
			name: "write_file",
			description: "Create or overwrite a project file. Use relative paths like index.html, styles.css, app.js.",
			parameters: {
				type: "object",
				properties: {
					path: { type: "string" },
					content: { type: "string" }
				},
				required: ["path", "content"]
			}
		}
	},
	{
		type: "function",
		function: {
			name: "read_file",
			description: "Read a file from the current project.",
			parameters: {
				type: "object",
				properties: { path: { type: "string" } },
				required: ["path"]
			}
		}
	},
	{
		type: "function",
		function: {
			name: "list_files",
			description: "List all files in the current project.",
			parameters: {
				type: "object",
				properties: {}
			}
		}
	},
	{
		type: "function",
		function: {
			name: "delete_file",
			description: "Delete a file from the current project.",
			parameters: {
				type: "object",
				properties: { path: { type: "string" } },
				required: ["path"]
			}
		}
	}
];
function systemPrompt(project, mode) {
	const fileIndex = Object.keys(project.files);
	return `You are Pulse Agent, an expert product engineer and designer. You vibe-code complete, beautiful, working apps.

Product: Pulse — an AI app builder. Auth and models run on Puter. Never mention competing products.

Mode: ${mode === "chat" ? "CHAT — brainstorm, answer, plan. Do not write files unless the user explicitly asks you to build." : "AGENT — you MUST build a complete working app by writing files. Do not stop at a plan."}

Build type: ${project.buildType}

Current files: ${fileIndex.length ? fileIndex.join(", ") : "(none yet)"}

Rules:
- Ship a real, self-contained web app that runs in an iframe with no external JS CDNs (Google Fonts CSS is ok).
- Prefer index.html as the entry. You may add styles.css and app.js. Inline CSS/JS is fine.
- Mobile-first, tap targets ≥44px, no horizontal overflow.
- Distinctive visual design: not generic SaaS purple, not Inter-on-white. Commit to a point of view.
- Include realistic sample content, working interactions, and empty/loading states.
- ${project.buildType === "mobile" ? "Design as a phone app (fixed app chrome, bottom nav if needed)." : ""}
- ${project.buildType === "slides" ? "Full-viewport slides, keyboard arrows + dots, one idea per slide." : ""}
- ${project.buildType === "dashboard" ? "Dense dashboard with KPIs and at least one chart drawn with SVG or canvas (no chart CDN)." : ""}
- When building, use write_file tools. If tools are unavailable, emit files as:
===FILE: index.html===
...contents...
===END===
- After building, give a short, concrete summary of what you made and how to try it. No fluff.
- Reply in the same language the user writes in.
- Keep assistant prose concise. The product is the files.`;
}
function applyTool(files, name, args) {
	if (name === "write_file") {
		const path = String(args.path ?? "index.html").replace(/^\/+/, "");
		const content = String(args.content ?? "");
		return {
			files: {
				...files,
				[path]: content
			},
			result: `Wrote ${path} (${content.length} chars)`,
			block: {
				kind: "file",
				path,
				action: "write"
			}
		};
	}
	if (name === "read_file") {
		const path = String(args.path ?? "");
		const content = files[path];
		return {
			files,
			result: content == null ? `Not found: ${path}` : content,
			block: {
				kind: "file",
				path,
				action: "read"
			}
		};
	}
	if (name === "list_files") {
		const keys = Object.keys(files);
		return {
			files,
			result: keys.length ? keys.join("\n") : "(empty project)"
		};
	}
	if (name === "delete_file") {
		const path = String(args.path ?? "");
		const next = { ...files };
		delete next[path];
		return {
			files: next,
			result: `Deleted ${path}`,
			block: {
				kind: "file",
				path,
				action: "delete"
			}
		};
	}
	return {
		files,
		result: `Unknown tool ${name}`
	};
}
async function runAgent(opts) {
	const store = usePulse.getState();
	const project = store.project(opts.projectId);
	if (!project) throw new Error("Project not found");
	const userMsg = {
		id: uid("msg"),
		role: "user",
		content: opts.userText,
		createdAt: Date.now()
	};
	store.appendMessage(opts.projectId, userMsg);
	const assistantId = uid("msg");
	const assistant = {
		id: assistantId,
		role: "assistant",
		content: "",
		createdAt: Date.now(),
		blocks: [{
			kind: "thinking",
			text: "Starting…"
		}]
	};
	store.appendMessage(opts.projectId, assistant);
	store.updateProject(opts.projectId, { status: "building" });
	const mode = project.mode;
	const model = routeModel({
		selected: store.settings.model === "auto" ? "auto" : store.settings.model,
		mode,
		prompt: opts.userText
	});
	let files = { ...project.files };
	const blocks = [];
	let prose = "";
	const changed = /* @__PURE__ */ new Set();
	const history = [
		{
			role: "system",
			content: systemPrompt({
				...project,
				files
			}, mode)
		},
		...project.messages.slice(-12).map((m) => ({
			role: m.role,
			content: m.content
		})),
		{
			role: "user",
			content: opts.userText
		}
	];
	try {
		const puter = await getPuter();
		const maxTurns = mode === "chat" ? 2 : 8;
		for (let turn = 0; turn < maxTurns; turn++) {
			if (opts.abort?.aborted) throw new Error("Cancelled");
			const options = {
				model,
				stream: true
			};
			if (mode === "agent") options.tools = AGENT_TOOLS;
			const call = store.settings.freeMode ? puter.ai.chat(history, true, options) : puter.ai.chat(history, options);
			const pendingTools = [];
			let turnText = "";
			await consumeChat(await call, (text, raw) => {
				if (text) {
					turnText += text;
					prose += text;
					usePulse.getState().patchMessage(opts.projectId, assistantId, {
						content: prose,
						blocks: [...blocks]
					});
				}
				const tools = extractToolCalls(raw);
				for (const t of tools) pendingTools.push(t);
			});
			const parsed = parseFilesFromText(turnText);
			if (Object.keys(parsed).length) {
				files = mergeFiles(files, parsed);
				for (const path of Object.keys(parsed)) {
					changed.add(path);
					blocks.push({
						kind: "file",
						path,
						action: "write"
					});
				}
				usePulse.getState().setFiles(opts.projectId, files);
			}
			if (!pendingTools.length) break;
			for (const tool of pendingTools) {
				const applied = applyTool(files, tool.name, tool.args);
				files = applied.files;
				if (applied.block) {
					blocks.push(applied.block);
					if (applied.block.kind === "file" && applied.block.action === "write") changed.add(applied.block.path);
				}
				history.push({
					role: "assistant",
					content: turnText || `call ${tool.name}`
				});
				history.push({
					role: "tool",
					tool_call_id: tool.id,
					content: applied.result
				});
			}
			usePulse.getState().setFiles(opts.projectId, files);
			usePulse.getState().patchMessage(opts.projectId, assistantId, {
				content: prose,
				blocks: [...blocks],
				filesChanged: [...changed]
			});
		}
		if (mode === "agent" && Object.keys(files).length === 0) blocks.push({
			kind: "text",
			text: "Agent did not emit files. Try again, or switch model in Account."
		});
		const hasFiles = Object.keys(files).length > 0;
		usePulse.getState().setFiles(opts.projectId, files);
		usePulse.getState().patchMessage(opts.projectId, assistantId, {
			content: prose.trim() || (hasFiles ? "Built the first version." : ""),
			blocks,
			filesChanged: [...changed]
		});
		usePulse.getState().updateProject(opts.projectId, {
			status: hasFiles || mode === "chat" ? "ready" : "error",
			name: project.name
		});
		if (mode === "agent") {
			const tasks = Object.keys(files).map((path) => ({
				id: uid("task"),
				title: `Write ${path}`,
				status: "done"
			}));
			if (tasks.length) usePulse.getState().setTasks(opts.projectId, tasks);
		}
	} catch (err) {
		const message = err instanceof Error ? err.message : "Agent failed";
		usePulse.getState().patchMessage(opts.projectId, assistantId, {
			content: prose || `Could not reach the model. ${message}`,
			blocks: [...blocks, {
				kind: "text",
				text: message
			}]
		});
		usePulse.getState().updateProject(opts.projectId, { status: "error" });
		throw err;
	}
}
//#endregion
export { runAgent as i, fileList as n, previewHtml as r, escapeHtml as t };
