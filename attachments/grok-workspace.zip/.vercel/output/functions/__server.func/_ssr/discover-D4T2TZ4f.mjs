import { C as require_jsx_runtime, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as usePulse } from "./router-zObRocos.mjs";
import { n as Shell } from "./shell-DKIrA96E.mjs";
import { n as STARTERS, t as BUILD_TYPES } from "./templates-B1GF2m3y.mjs";
import { i as runAgent } from "./agent-kJQiei1d.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/discover-D4T2TZ4f.js
var import_jsx_runtime = require_jsx_runtime();
function DiscoverPage() {
	const navigate = useNavigate();
	const createProject = usePulse((s) => s.createProject);
	const model = usePulse((s) => s.settings.model);
	async function remix(id) {
		const s = STARTERS.find((x) => x.id === id);
		if (!s) return;
		const project = createProject({
			prompt: s.prompt,
			buildType: s.buildType,
			mode: "agent",
			model
		});
		await navigate({
			to: "/project/$id",
			params: { id: project.id }
		});
		try {
			await runAgent({
				projectId: project.id,
				userText: s.prompt
			});
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-6 md:px-8 md:pt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight",
				children: "Discover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Remix a template. Agent rebuilds it as yours."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-3 sm:grid-cols-2",
				children: STARTERS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => remix(s.id),
					className: "rounded-[22px] bg-surface p-4 text-left shadow-[var(--shadow-border)] transition-colors hover:bg-elevated",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-medium tracking-wide text-primary uppercase",
							children: BUILD_TYPES.find((t) => t.id === s.buildType)?.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 text-[16px] font-semibold",
							children: s.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: s.blurb
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-subtle",
							children: s.tone
						})
					]
				}, s.id))
			})
		]
	}) });
}
//#endregion
export { DiscoverPage as component };
