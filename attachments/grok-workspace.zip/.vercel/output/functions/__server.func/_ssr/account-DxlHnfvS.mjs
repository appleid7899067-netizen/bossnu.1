import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as cn, d as puterSignIn, f as puterSignOut, h as usePulse, r as Button, s as currentPuterUser } from "./router-zObRocos.mjs";
import { n as Shell, t as Avatar } from "./shell-DKIrA96E.mjs";
import { t as MODEL_OPTIONS } from "./models-B4ceBp4S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-DxlHnfvS.js
var import_jsx_runtime = require_jsx_runtime();
function AccountPage() {
	const user = usePulse((s) => s.user);
	const guest = usePulse((s) => s.guest);
	const settings = usePulse((s) => s.settings);
	const setSettings = usePulse((s) => s.setSettings);
	const setUser = usePulse((s) => s.setUser);
	const setGuest = usePulse((s) => s.setGuest);
	const projects = usePulse((s) => s.projects);
	async function signIn() {
		await puterSignIn();
		setUser(await currentPuterUser());
		await usePulse.getState().hydrateFromCloud();
	}
	async function signOut() {
		try {
			await puterSignOut();
		} catch {}
		setUser(null);
		setGuest(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-6 md:px-8 md:pt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight",
				children: "You"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center gap-4 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name: user?.username }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-semibold",
						children: user?.username ?? "Guest"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-muted",
						children: user?.email || (guest ? "Browsing as guest · Puter login for Agent" : "Puter account")
					})]
				})]
			}),
			!user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4 w-full rounded-2xl",
				onClick: signIn,
				children: "Sign in with Puter"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4 w-full rounded-2xl",
				variant: "secondary",
				onClick: signOut,
				children: "Sign out"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium tracking-wide text-subtle uppercase",
					children: "Free Mode"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setSettings({ freeMode: !settings.freeMode }),
					className: "mt-3 flex w-full items-center justify-between rounded-2xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Build without spending credits"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-xs text-muted",
							children: "Uses Puter test mode for Agent calls"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("relative h-7 w-12 rounded-full transition-colors", settings.freeMode ? "bg-primary" : "bg-hover"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 size-6 rounded-full bg-fg transition-transform", settings.freeMode ? "translate-x-5" : "translate-x-0.5") })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs font-medium tracking-wide text-subtle uppercase",
						children: "Intelligent model routing"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Auto picks a model from Puter’s catalog as the work gets simpler or harder."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-col gap-1.5",
						children: MODEL_OPTIONS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSettings({ model: m.id }),
							className: cn("rounded-2xl px-4 py-3 text-left shadow-[var(--shadow-border)]", settings.model === m.id ? "bg-elevated ring-1 ring-primary/40" : "bg-surface"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: m.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: m.hint
							})]
						}, m.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-8 text-xs text-subtle",
				children: [
					projects.length,
					" app",
					projects.length === 1 ? "" : "s",
					" on this device",
					user ? " · synced to Puter KV" : ""
				]
			})
		]
	}) });
}
//#endregion
export { AccountPage as component };
