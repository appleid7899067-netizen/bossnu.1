import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as usePulse } from "./router-zObRocos.mjs";
import { n as Shell, t as Avatar } from "./shell-DKIrA96E.mjs";
import { t as ProjectCard } from "./project-card-DOyu6jxF.mjs";
import { n as STARTERS } from "./templates-B1GF2m3y.mjs";
import { i as runAgent } from "./agent-kJQiei1d.mjs";
import { t as PromptBox } from "./prompt-box-DIy5INA_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C-H2npL-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const navigate = useNavigate();
	const user = usePulse((s) => s.user);
	const projects = usePulse((s) => s.projects);
	const createProject = usePulse((s) => s.createProject);
	const model = usePulse((s) => s.settings.model);
	const [prompt, setPrompt] = (0, import_react.useState)("");
	const [mode, setMode] = (0, import_react.useState)("agent");
	const [buildType, setBuildType] = (0, import_react.useState)("web");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const recents = [...projects].sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt).slice(0, 6);
	const hour = (/* @__PURE__ */ new Date()).getHours();
	const hello = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
	async function start(text, type = buildType, m = mode) {
		const value = text.trim();
		if (!value || busy) return;
		setBusy(true);
		const project = createProject({
			prompt: value,
			buildType: type,
			mode: m,
			model
		});
		await navigate({
			to: "/project/$id",
			params: { id: project.id }
		});
		try {
			await runAgent({
				projectId: project.id,
				userText: value
			});
		} catch {} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "flex items-center justify-between px-5 pt-5 md:px-8 md:pt-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name: user?.username }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-subtle",
					children: hello
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: user?.username ?? "Guest"
				})] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto w-full max-w-2xl px-5 pt-10 md:pt-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-center text-[1.85rem] font-semibold tracking-tight md:text-[2.35rem]",
					children: "What do you want to make?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-2 max-w-md text-center text-sm text-muted",
					children: "Agent builds it. Chat shapes it first. Models run on your Puter account."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptBox, {
						value: prompt,
						onChange: setPrompt,
						onSubmit: () => start(prompt),
						mode,
						onMode: setMode,
						buildType,
						onBuildType: setBuildType,
						disabled: busy,
						busy
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto mt-10 w-full max-w-2xl px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-xs font-medium tracking-wide text-subtle uppercase",
				children: "Try these"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2.5",
				children: STARTERS.slice(0, 4).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => start(s.prompt, s.buildType, "agent"),
					className: "rounded-2xl bg-surface p-3.5 text-left shadow-[var(--shadow-border)] transition-colors hover:bg-elevated",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[13px] font-semibold",
						children: s.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs leading-relaxed text-muted",
						children: s.blurb
					})]
				}, s.id))
			})]
		}),
		recents.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto mt-10 w-full max-w-2xl px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-xs font-medium tracking-wide text-subtle uppercase",
				children: "Recent projects"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-2.5",
				children: recents.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectCard, { project: p }, p.id))
			})]
		}) : null
	] });
}
//#endregion
export { Home as component };
