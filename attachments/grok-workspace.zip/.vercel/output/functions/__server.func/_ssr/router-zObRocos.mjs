import { i as __toESM } from "../_runtime.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { C as require_jsx_runtime, S as useRouter, Y as require_react, _ as lazyRouteComponent, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, v as createFileRoute, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-DenJlzZR.js
var PUTER_SRC = "https://js.puter.com/v2/";
var loading = null;
function loadPuterScript() {
	return new Promise((resolve, reject) => {
		const existing = document.querySelector(`script[src="${PUTER_SRC}"]`);
		const done = () => {
			if (window.puter) resolve(window.puter);
			else reject(/* @__PURE__ */ new Error("Puter.js loaded without window.puter"));
		};
		if (existing) {
			if (window.puter) {
				resolve(window.puter);
				return;
			}
			existing.addEventListener("load", done, { once: true });
			existing.addEventListener("error", () => reject(/* @__PURE__ */ new Error("Failed to load Puter.js")), { once: true });
			return;
		}
		const script = document.createElement("script");
		script.src = PUTER_SRC;
		script.async = true;
		script.onload = done;
		script.onerror = () => reject(/* @__PURE__ */ new Error("Failed to load Puter.js"));
		document.head.appendChild(script);
	});
}
async function getPuter() {
	if (typeof window === "undefined") throw new Error("Puter only runs in the browser");
	if (window.puter) return window.puter;
	if (!loading) loading = loadPuterScript().catch((err) => {
		loading = null;
		throw err;
	});
	return loading;
}
async function puterSignIn() {
	const puter = await getPuter();
	await puter.auth.signIn({ attempt_temp_user_creation: true });
	return puter.auth.getUser();
}
async function puterSignOut() {
	await (await getPuter()).auth.signOut();
}
async function currentPuterUser() {
	const puter = await getPuter();
	if (!puter.auth.isSignedIn()) return null;
	try {
		return await puter.auth.getUser();
	} catch {
		return null;
	}
}
function chunkText(part) {
	if (!part) return "";
	if (typeof part === "string") return part;
	if (typeof part !== "object") return "";
	const p = part;
	if (typeof p.text === "string") return p.text;
	if (typeof p.content === "string") return p.content;
	if (p.delta && typeof p.delta === "object") {
		const d = p.delta;
		if (typeof d.content === "string") return d.content;
		if (typeof d.text === "string") return d.text;
	}
	const msg = p.message;
	if (msg && typeof msg.content === "string") return msg.content;
	return "";
}
function extractToolCalls(part) {
	if (!part || typeof part !== "object") return [];
	const p = part;
	const out = [];
	if (p.type === "tool_use" && typeof p.name === "string") out.push({
		id: String(p.id ?? p.tool_use_id ?? `tool_${out.length}`),
		name: p.name,
		args: asArgs(p.input ?? p.arguments)
	});
	const calls = p.tool_calls || p.message?.tool_calls;
	if (Array.isArray(calls)) for (const c of calls) {
		const name = c.function?.name || c.name;
		if (!name) continue;
		out.push({
			id: String(c.id ?? `tool_${out.length}`),
			name,
			args: asArgs(c.function?.arguments ?? c.input)
		});
	}
	return out;
}
function asArgs(raw) {
	if (!raw) return {};
	if (typeof raw === "string") try {
		const parsed = JSON.parse(raw);
		if (parsed && typeof parsed === "object") return parsed;
	} catch {
		return { value: raw };
	}
	if (typeof raw === "object") return raw;
	return {};
}
async function consumeChat(result, onChunk) {
	let full = "";
	if (result && typeof result === "object" && Symbol.asyncIterator in result) {
		for await (const part of result) {
			const t = chunkText(part);
			if (t) full += t;
			onChunk(t, part);
		}
		return full;
	}
	const t = chunkText(result);
	if (t) {
		full = t;
		onChunk(t, result);
	}
	return full;
}
function slugify(input) {
	const base = input.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 24);
	const n = Math.random().toString(36).slice(2, 6);
	return `${base || "pulse"}-${n}`;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}
function formatRelative(ts) {
	const diff = Date.now() - ts;
	const min = Math.floor(diff / 6e4);
	if (min < 1) return "Just now";
	if (min < 60) return `${min}m ago`;
	const hr = Math.floor(min / 60);
	if (hr < 24) return `${hr}h ago`;
	const day = Math.floor(hr / 24);
	if (day < 7) return `${day}d ago`;
	return new Date(ts).toLocaleDateString(void 0, {
		month: "short",
		day: "numeric"
	});
}
function titleFromPrompt(prompt) {
	const cleaned = prompt.replace(/\s+/g, " ").trim();
	if (!cleaned) return "Untitled app";
	const cut = cleaned.length > 42 ? `${cleaned.slice(0, 40).trim()}…` : cleaned;
	return cut.charAt(0).toUpperCase() + cut.slice(1);
}
var KV_KEY = "pulse:projects:v1";
var usePulse = create()(persist((set, get) => ({
	ready: true,
	user: null,
	guest: false,
	settings: {
		model: "auto",
		freeMode: false,
		seenLogin: false
	},
	projects: [],
	setReady: (ready) => set({ ready }),
	setUser: (user) => set({
		user,
		guest: user ? false : get().guest
	}),
	setGuest: (guest) => set({
		guest,
		settings: {
			...get().settings,
			seenLogin: true
		}
	}),
	setSettings: (p) => set({ settings: {
		...get().settings,
		...p,
		seenLogin: true
	} }),
	createProject: ({ prompt, buildType, mode, model }) => {
		const now = Date.now();
		const project = {
			id: uid("app"),
			name: titleFromPrompt(prompt),
			prompt,
			buildType,
			mode,
			status: "draft",
			pinned: false,
			createdAt: now,
			updatedAt: now,
			files: {},
			messages: [],
			tasks: [],
			model
		};
		set({ projects: [project, ...get().projects] });
		get().persistCloud();
		return project;
	},
	updateProject: (id, patch) => {
		set({ projects: get().projects.map((p) => p.id === id ? {
			...p,
			...patch,
			updatedAt: Date.now()
		} : p) });
		get().persistCloud();
	},
	appendMessage: (id, msg) => {
		set({ projects: get().projects.map((p) => p.id === id ? {
			...p,
			messages: [...p.messages, msg],
			updatedAt: Date.now()
		} : p) });
		get().persistCloud();
	},
	patchMessage: (projectId, msgId, patch) => {
		set({ projects: get().projects.map((p) => p.id === projectId ? {
			...p,
			messages: p.messages.map((m) => m.id === msgId ? {
				...m,
				...patch
			} : m),
			updatedAt: Date.now()
		} : p) });
	},
	setFiles: (id, files) => {
		set({ projects: get().projects.map((p) => p.id === id ? {
			...p,
			files,
			updatedAt: Date.now()
		} : p) });
		get().persistCloud();
	},
	setTasks: (id, tasks) => {
		set({ projects: get().projects.map((p) => p.id === id ? {
			...p,
			tasks,
			updatedAt: Date.now()
		} : p) });
	},
	deleteProject: (id) => {
		set({ projects: get().projects.filter((p) => p.id !== id) });
		get().persistCloud();
	},
	togglePin: (id) => {
		set({ projects: get().projects.map((p) => p.id === id ? {
			...p,
			pinned: !p.pinned
		} : p) });
		get().persistCloud();
	},
	project: (id) => get().projects.find((p) => p.id === id),
	hydrateFromCloud: async () => {
		try {
			const puter = await getPuter();
			if (!puter.auth.isSignedIn()) return;
			const raw = await puter.kv.get(KV_KEY);
			if (!raw) return;
			const parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
			if (!parsed || typeof parsed !== "object") return;
			const cloud = parsed.projects;
			if (!Array.isArray(cloud) || cloud.length === 0) return;
			const local = get().projects;
			const byId = new Map(local.map((p) => [p.id, p]));
			for (const p of cloud) {
				const existing = byId.get(p.id);
				if (!existing || p.updatedAt > existing.updatedAt) byId.set(p.id, p);
			}
			set({ projects: [...byId.values()].sort((a, b) => b.updatedAt - a.updatedAt) });
		} catch {}
	},
	persistCloud: async () => {
		try {
			const puter = await getPuter();
			if (!puter.auth.isSignedIn()) return;
			await puter.kv.set(KV_KEY, JSON.stringify({
				projects: get().projects,
				savedAt: Date.now()
			}));
		} catch {}
	}
}), {
	name: "pulse-local",
	partialize: (s) => ({
		projects: s.projects,
		settings: s.settings,
		guest: s.guest
	})
}));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-zObRocos.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function PuterBoot() {
	const setUser = usePulse((s) => s.setUser);
	const setReady = usePulse((s) => s.setReady);
	(0, import_react.useEffect)(() => {
		setReady(true);
		let cancelled = false;
		(async () => {
			try {
				await getPuter();
				if (cancelled) return;
				const user = await currentPuterUser();
				if (cancelled || !user) return;
				setUser(user);
				await usePulse.getState().hydrateFromCloud();
			} catch {}
		})();
		return () => {
			cancelled = true;
		};
	}, [setUser, setReady]);
	return null;
}
function PulseMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("shrink-0", className),
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "9",
			fill: "#f26207"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M6 17h4l2.2-6 3.6 12 2.4-8H26",
			fill: "none",
			stroke: "#fff7ed",
			strokeWidth: "2.2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,color] duration-150 ease-out active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary", {
	variants: {
		variant: {
			primary: "bg-primary text-primary-fg hover:bg-primary-hover shadow-[0_1px_0_rgba(255,255,255,0.12)_inset]",
			secondary: "bg-elevated text-fg shadow-[0_0_0_1px_rgba(255,255,255,0.08)] hover:bg-hover",
			ghost: "bg-transparent text-muted hover:bg-hover hover:text-fg",
			danger: "bg-danger/15 text-danger hover:bg-danger/25",
			orange: "bg-primary text-primary-fg hover:bg-primary-hover rounded-full"
		},
		size: {
			sm: "h-9 px-3 text-sm rounded-lg",
			md: "h-11 px-4 text-sm rounded-xl",
			lg: "h-12 px-5 text-[15px] rounded-xl",
			icon: "size-11 rounded-xl",
			"icon-sm": "size-9 rounded-lg"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function LoginScreen() {
	const setUser = usePulse((s) => s.setUser);
	const setGuest = usePulse((s) => s.setGuest);
	const setSettings = usePulse((s) => s.setSettings);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function signIn() {
		setBusy(true);
		setError(null);
		try {
			await puterSignIn();
			const user = await currentPuterUser();
			setUser(user);
			setSettings({ seenLogin: true });
			await usePulse.getState().hydrateFromCloud();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Sign in was blocked. Allow popups, then try again.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh flex-col items-center justify-center overflow-hidden bg-bg px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"aria-hidden": true,
			className: "pointer-events-none absolute inset-x-0 top-0 h-[420px] opacity-70",
			style: { background: "radial-gradient(ellipse 80% 60% at 50% -10%, rgba(242,98,7,0.22), transparent 60%)" }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative w-full max-w-sm text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-8 grid size-16 place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PulseMark, { className: "size-16" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[2rem] font-semibold tracking-tight",
					children: "Pulse"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-[15px] leading-relaxed text-muted",
					children: "Vibe code with AI. Describe an app, watch Agent build it, publish it from your phone."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full rounded-2xl",
						onClick: signIn,
						disabled: busy,
						children: busy ? "Opening Puter…" : "Continue with Puter"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "secondary",
						className: "w-full rounded-2xl",
						onClick: () => setGuest(true),
						children: "Continue as guest"
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-xs leading-relaxed text-subtle",
					children: "Login and models run on your Puter account. Pulse never stores API keys. Guest mode still uses Puter when Agent starts."
				})
			]
		})]
	});
}
var styles_default = "/assets/styles-BmlpkU8a.css";
var APP_NAME = "Pulse";
var Route$5 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#0c0c0d"
			},
			{
				name: "description",
				content: "Pulse — vibe code with AI. Login and models via Puter."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PuterBoot, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
function Gate({ children }) {
	const ready = usePulse((s) => s.ready);
	const user = usePulse((s) => s.user);
	const guest = usePulse((s) => s.guest);
	const seen = usePulse((s) => s.settings.seenLogin);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-8 animate-pulse rounded-xl bg-primary" })
	});
	if (!user && !guest && !seen) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var $$splitComponentImporter$4 = () => import("./routes-C-H2npL-.mjs");
var Route$4 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./account-DxlHnfvS.mjs");
var Route$3 = createFileRoute("/account")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./apps-BsGjFnwq.mjs");
var Route$2 = createFileRoute("/apps")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./discover-D4T2TZ4f.mjs");
var Route$1 = createFileRoute("/discover")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./project._id-DKn6gKxC.mjs");
var Route = createFileRoute("/project/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$4.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$5
	}),
	AccountRoute: Route$3.update({
		id: "/account",
		path: "/account",
		getParentRoute: () => Route$5
	}),
	AppsRoute: Route$2.update({
		id: "/apps",
		path: "/apps",
		getParentRoute: () => Route$5
	}),
	DiscoverRoute: Route$1.update({
		id: "/discover",
		path: "/discover",
		getParentRoute: () => Route$5
	}),
	ProjectIdRoute: Route.update({
		id: "/project/$id",
		path: "/project/$id",
		getParentRoute: () => Route$5
	})
};
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { cn as a, extractToolCalls as c, puterSignIn as d, puterSignOut as f, usePulse as h, PulseMark as i, formatRelative as l, uid as m, Route as n, consumeChat as o, slugify as p, Button as r, currentPuterUser as s, router_exports as t, getPuter as u };
