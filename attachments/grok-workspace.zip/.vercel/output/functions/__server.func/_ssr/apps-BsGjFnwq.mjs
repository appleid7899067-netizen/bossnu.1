import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as Search } from "../_libs/lucide-react.mjs";
import { h as usePulse } from "./router-zObRocos.mjs";
import { n as Shell } from "./shell-DKIrA96E.mjs";
import { t as ProjectCard } from "./project-card-DOyu6jxF.mjs";
import { t as BUILD_TYPES } from "./templates-B1GF2m3y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/apps-BsGjFnwq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AppsPage() {
	const projects = usePulse((s) => s.projects);
	const [q, setQ] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("all");
	const [sort, setSort] = (0, import_react.useState)("opened");
	const list = (0, import_react.useMemo)(() => {
		let rows = [...projects];
		if (type !== "all") rows = rows.filter((p) => p.buildType === type);
		if (q.trim()) {
			const s = q.toLowerCase();
			rows = rows.filter((p) => p.name.toLowerCase().includes(s) || p.prompt.toLowerCase().includes(s));
		}
		rows.sort((a, b) => {
			if (a.pinned !== b.pinned) return Number(b.pinned) - Number(a.pinned);
			if (sort === "name") return a.name.localeCompare(b.name);
			return b.updatedAt - a.updatedAt;
		});
		return rows;
	}, [
		projects,
		q,
		type,
		sort
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-6 md:px-8 md:pt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight",
				children: "Apps"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Everything you’ve built in Pulse."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center gap-2 rounded-2xl bg-surface px-3 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search apps",
					className: "h-12 w-full bg-transparent text-sm text-fg placeholder:text-subtle focus:outline-none"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2 overflow-x-auto no-scrollbar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: type === "all",
					onClick: () => setType("all"),
					children: "Any type"
				}), BUILD_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: type === t.id,
					onClick: () => setType(t.id),
					children: t.label
				}, t.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: sort === "opened" ? "text-fg" : "text-subtle",
						onClick: () => setSort("opened"),
						children: "Last opened"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-subtle",
						children: "·"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: sort === "name" ? "text-fg" : "text-subtle",
						onClick: () => setSort("name"),
						children: "Name"
					})
				]
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-16 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "No apps yet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Describe something on Create and Agent will start."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "mt-4 inline-block text-sm font-medium text-primary",
						children: "New app"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex flex-col gap-2.5 pb-4",
				children: list.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectCard, { project: p }, p.id))
			})
		]
	}) });
}
function Chip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `h-8 shrink-0 rounded-full px-3 text-xs font-medium ${active ? "bg-primary text-primary-fg" : "bg-surface text-muted"}`,
		children
	});
}
//#endregion
export { AppsPage as component };
